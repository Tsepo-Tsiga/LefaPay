import { v4 as uuidv4 } from 'uuid';
import { db } from './database.js';

export interface Cashbook {
  id: string;
  business_id: string;
  name: string;
  description: string | null;
  currency: string;
  opening_balance: number;
  current_balance: number;
  is_active: number;
  created_at: string;
  updated_at: string;
}

export interface CashbookTransaction {
  id: string;
  cashbook_id: string;
  business_id: string;
  transaction_type: 'credit' | 'debit';
  amount: number;
  description: string;
  reference: string | null;
  category: string | null;
  payment_method: string | null;
  source_id: string | null;
  source_type: string | null;
  balance_after: number;
  created_at: string;
  created_by: string | null;
}

export async function createCashbook(
  businessId: string,
  name: string,
  description: string | null = null,
  openingBalance: number = 0,
  currency: string = 'LSL'
): Promise<string> {
  console.log('Creating cashbook:', { businessId, name, openingBalance });
  
  const cashbookId = uuidv4();
  
  await db
    .insertInto('cashbooks')
    .values({
      id: cashbookId,
      business_id: businessId,
      name,
      description,
      currency,
      opening_balance: openingBalance,
      current_balance: openingBalance,
      is_active: 1,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .execute();

  // If there's an opening balance, create an initial transaction
  if (openingBalance !== 0) {
    await addCashbookTransaction(
      cashbookId,
      businessId,
      openingBalance > 0 ? 'credit' : 'debit',
      Math.abs(openingBalance),
      'Opening balance',
      'OPENING',
      'Opening Balance',
      null,
      null,
      null
    );
  }

  console.log('Cashbook created successfully:', cashbookId);
  return cashbookId;
}

export async function addCashbookTransaction(
  cashbookId: string,
  businessId: string,
  transactionType: 'credit' | 'debit',
  amount: number,
  description: string,
  reference: string | null = null,
  category: string | null = null,
  paymentMethod: string | null = null,
  sourceId: string | null = null,
  sourceType: string | null = null,
  createdBy: string | null = null
): Promise<string> {
  console.log('Adding cashbook transaction:', { cashbookId, transactionType, amount, description });

  // Get current cashbook balance
  const cashbook = await db
    .selectFrom('cashbooks')
    .select(['current_balance'])
    .where('id', '=', cashbookId)
    .where('business_id', '=', businessId)
    .executeTakeFirst();

  if (!cashbook) {
    throw new Error('Cashbook not found');
  }

  const currentBalance = cashbook.current_balance;
  const balanceChange = transactionType === 'credit' ? amount : -amount;
  const newBalance = currentBalance + balanceChange;

  // Check for negative balance on debit transactions
  if (newBalance < 0 && transactionType === 'debit') {
    throw new Error('Insufficient funds in cashbook');
  }

  const transactionId = uuidv4();

  // Start transaction to ensure data consistency
  await db.transaction().execute(async (trx) => {
    // Insert transaction record
    await trx
      .insertInto('cashbook_transactions')
      .values({
        id: transactionId,
        cashbook_id: cashbookId,
        business_id: businessId,
        transaction_type: transactionType,
        amount,
        description,
        reference,
        category,
        payment_method: paymentMethod,
        source_id: sourceId,
        source_type: sourceType,
        balance_after: newBalance,
        created_at: new Date().toISOString(),
        created_by: createdBy
      })
      .execute();

    // Update cashbook balance
    await trx
      .updateTable('cashbooks')
      .set({
        current_balance: newBalance,
        updated_at: new Date().toISOString()
      })
      .where('id', '=', cashbookId)
      .execute();
  });

  console.log('Cashbook transaction added:', transactionId, 'New balance:', newBalance);
  return transactionId;
}

export async function getBusinessCashbooks(businessId: string): Promise<Cashbook[]> {
  const cashbooks = await db
    .selectFrom('cashbooks')
    .selectAll()
    .where('business_id', '=', businessId)
    .where('is_active', '=', 1)
    .orderBy('created_at', 'desc')
    .execute();

  return cashbooks;
}

export async function getCashbookTransactions(
  cashbookId: string,
  businessId: string,
  limit: number = 50,
  offset: number = 0
): Promise<CashbookTransaction[]> {
  const transactions = await db
    .selectFrom('cashbook_transactions')
    .selectAll()
    .where('cashbook_id', '=', cashbookId)
    .where('business_id', '=', businessId)
    .orderBy('created_at', 'desc')
    .limit(limit)
    .offset(offset)
    .execute();

  return transactions;
}

export async function getCashbookById(cashbookId: string, businessId: string): Promise<Cashbook | null> {
  const cashbook = await db
    .selectFrom('cashbooks')
    .selectAll()
    .where('id', '=', cashbookId)
    .where('business_id', '=', businessId)
    .executeTakeFirst();

  return cashbook || null;
}

export async function updateCashbook(
  cashbookId: string,
  businessId: string,
  updates: Partial<Pick<Cashbook, 'name' | 'description'>>
): Promise<void> {
  console.log('Updating cashbook:', cashbookId, updates);

  await db
    .updateTable('cashbooks')
    .set({
      ...updates,
      updated_at: new Date().toISOString()
    })
    .where('id', '=', cashbookId)
    .where('business_id', '=', businessId)
    .execute();

  console.log('Cashbook updated successfully');
}

export async function deactivateCashbook(cashbookId: string, businessId: string): Promise<void> {
  console.log('Deactivating cashbook:', cashbookId);

  await db
    .updateTable('cashbooks')
    .set({
      is_active: 0,
      updated_at: new Date().toISOString()
    })
    .where('id', '=', cashbookId)
    .where('business_id', '=', businessId)
    .execute();

  console.log('Cashbook deactivated successfully');
}

export async function getCashbookSummary(businessId: string): Promise<{
  totalCashbooks: number;
  totalBalance: number;
  activeCashbooks: number;
}> {
  const summary = await db
    .selectFrom('cashbooks')
    .select(({ fn }) => [
      fn.count<number>('id').as('totalCashbooks'),
      fn.sum<number>('current_balance').as('totalBalance'),
      fn.count<number>('id').filterWhere('is_active', '=', 1).as('activeCashbooks')
    ])
    .where('business_id', '=', businessId)
    .executeTakeFirst();

  return {
    totalCashbooks: summary?.totalCashbooks || 0,
    totalBalance: summary?.totalBalance || 0,
    activeCashbooks: summary?.activeCashbooks || 0
  };
}

export async function recordPaymentReceiptToCashbook(
  businessId: string,
  paymentId: string,
  amount: number,
  cashbookId: string | null = null
): Promise<void> {
  console.log('Recording payment receipt to cashbook:', { businessId, paymentId, amount, cashbookId });

  // If no specific cashbook is provided, use the default one or create one
  let targetCashbookId = cashbookId;
  
  if (!targetCashbookId) {
    // Find the default cashbook (first active one) or create one
    const defaultCashbook = await db
      .selectFrom('cashbooks')
      .select(['id'])
      .where('business_id', '=', businessId)
      .where('is_active', '=', 1)
      .orderBy('created_at', 'asc')
      .executeTakeFirst();

    if (defaultCashbook) {
      targetCashbookId = defaultCashbook.id;
    } else {
      // Create a default cashbook
      targetCashbookId = await createCashbook(businessId, 'Main Cash Account', 'Default cash account for payments');
    }
  }

  // Record the payment as a credit transaction
  await addCashbookTransaction(
    targetCashbookId,
    businessId,
    'credit',
    amount,
    `Payment received - ${paymentId}`,
    paymentId,
    'Payment Receipt',
    'Online Payment',
    paymentId,
    'payment'
  );

  console.log('Payment receipt recorded to cashbook successfully');
}
