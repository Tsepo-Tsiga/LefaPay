import path from 'path';
import express from 'express';
import { promises as fs } from 'fs';

/**
 * Sets up static file serving for the Express app
 * @param app Express application instance
 */
export async function setupStaticServing(app: express.Application) {
  // Ensure uploads directory exists
  try {
    const dataDirectory = process.env.DATA_DIRECTORY || './data';
    const uploadsDir = path.join(dataDirectory, 'uploads');
    await fs.mkdir(uploadsDir, { recursive: true });
    console.log('Uploads directory created/verified:', uploadsDir);
  } catch (error) {
    console.error('Error creating uploads directory:', error);
  }

  // Serve static files from the public directory
  app.use(express.static(path.join(process.cwd(), 'public')));

  // For any non-API routes, serve the index.html file (SPA fallback)
  app.get('/*splat', (req, res, next) => {
    // Skip API routes - let them be handled by their respective handlers
    if (req.path.startsWith('/api/')) {
      return next();
    }
    
    console.log('Serving SPA for route:', req.path);
    res.sendFile(path.join(process.cwd(), 'public', 'index.html'));
  });
}
