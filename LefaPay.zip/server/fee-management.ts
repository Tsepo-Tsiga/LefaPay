import { v4 as uuidv4 } from 'uuid';
import { db } from './database.js';

export const FEE_PERCENTAGE = 5.7;
export const MONTHLY_SUBSCRIPTION_FEE = 300.0;

export async function calculateAndCreateTransactionFee(paymentId: string, businessId: string, transactionAmount: number) {
  console.log('Calculating transaction fee for payment:', paymentId, 'Amount:', transactionAmount);
  
  const feeAmount = (transactionAmount * FEE_PERCENTAGE) / 100;
  const netAmount = transactionAmount - feeAmount;
  
  const feeId = uuidv4();
  
  // Create transaction fee record
  await db
    .insertInto('transaction_fees')
    .values({
      id: feeId,
      payment_id: paymentId,
      business_id: businessId,
      transaction_amount: transactionAmount,
      fee_percentage: FEE_PERCENTAGE,
      fee_amount: feeAmount,
      net_amount: netAmount,
      status: 'pending',
      transferred_at: null,
      created_at: new Date().toISOString()
    })
    .execute();
  
  // Create company revenue record
  const revenueId = uuidv4();
  await db
    .insertInto('company_revenue')
    .values({
      id: revenueId,
      revenue_type: 'transaction_fee',
      source_id: feeId,
      business_id: businessId,
      amount: feeAmount,
      description: `5.7% transaction fee from payment ${paymentId}`,
      transferred_to_bank: 0,
      transfer_date: null,
      created_at: new Date().toISOString()
    })
    .execute();
  
  console.log('Transaction fee created:', feeId, 'Fee amount:', feeAmount, 'Net amount:', netAmount);
  
  return {
    feeId,
    feeAmount,
    netAmount,
    revenueId
  };
}

export async function createMonthlySubscriptionFee(businessId: string) {
  console.log('Creating monthly subscription fee for business:', businessId);
  
  const now = new Date();
  const dueDate = new Date(now.getFullYear(), now.getMonth() + 1, 1); // First day of next month
  
  const subscriptionId = uuidv4();
  
  await db
    .insertInto('subscription_fees')
    .values({
      id: subscriptionId,
      business_id: businessId,
      amount: MONTHLY_SUBSCRIPTION_FEE,
      currency: 'LSL',
      billing_period: 'monthly',
      due_date: dueDate.toISOString().split('T')[0], // YYYY-MM-DD format
      paid_date: null,
      status: 'pending',
      payment_method: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .execute();
  
  console.log('Monthly subscription fee created:', subscriptionId, 'Due date:', dueDate.toISOString());
  
  return subscriptionId;
}

export async function processSubscriptionPayment(subscriptionId: string, paymentMethod: string) {
  console.log('Processing subscription payment:', subscriptionId);
  
  const subscription = await db
    .selectFrom('subscription_fees')
    .selectAll()
    .where('id', '=', subscriptionId)
    .executeTakeFirst();
  
  if (!subscription) {
    throw new Error('Subscription not found');
  }
  
  // Update subscription as paid
  await db
    .updateTable('subscription_fees')
    .set({
      paid_date: new Date().toISOString().split('T')[0],
      status: 'paid',
      payment_method: paymentMethod,
      updated_at: new Date().toISOString()
    })
    .where('id', '=', subscriptionId)
    .execute();
  
  // Create company revenue record
  const revenueId = uuidv4();
  await db
    .insertInto('company_revenue')
    .values({
      id: revenueId,
      revenue_type: 'subscription_fee',
      source_id: subscriptionId,
      business_id: subscription.business_id,
      amount: subscription.amount,
      description: `Monthly subscription fee - ${subscription.billing_period}`,
      transferred_to_bank: 0,
      transfer_date: null,
      created_at: new Date().toISOString()
    })
    .execute();
  
  console.log('Subscription payment processed:', subscriptionId, 'Revenue record:', revenueId);
  
  return revenueId;
}

export async function markRevenueAsTransferred(revenueIds: string[]) {
  console.log('Marking revenue as transferred to bank:', revenueIds);
  
  const transferDate = new Date().toISOString();
  
  await db
    .updateTable('company_revenue')
    .set({
      transferred_to_bank: 1,
      transfer_date: transferDate
    })
    .where('id', 'in', revenueIds)
    .execute();
  
  // Also update related transaction fees
  const transactionFeeIds = await db
    .selectFrom('company_revenue')
    .select('source_id')
    .where('id', 'in', revenueIds)
    .where('revenue_type', '=', 'transaction_fee')
    .execute();
  
  if (transactionFeeIds.length > 0) {
    const feeIds = transactionFeeIds.map(tf => tf.source_id);
    await db
      .updateTable('transaction_fees')
      .set({
        status: 'transferred',
        transferred_at: transferDate
      })
      .where('id', 'in', feeIds)
      .execute();
  }
  
  console.log('Revenue marked as transferred:', revenueIds.length, 'records');
}

export async function getBusinessTransactionFees(businessId: string) {
  const fees = await db
    .selectFrom('transaction_fees')
    .leftJoin('payments', 'transaction_fees.payment_id', 'payments.id')
    .select([
      'transaction_fees.id',
      'transaction_fees.transaction_amount',
      'transaction_fees.fee_amount',
      'transaction_fees.net_amount',
      'transaction_fees.status',
      'transaction_fees.created_at',
      'payments.reference',
      'payments.customer_name'
    ])
    .where('transaction_fees.business_id', '=', businessId)
    .orderBy('transaction_fees.created_at', 'desc')
    .execute();
  
  return fees;
}

export async function getBusinessSubscriptionFees(businessId: string) {
  const fees = await db
    .selectFrom('subscription_fees')
    .selectAll()
    .where('business_id', '=', businessId)
    .orderBy('created_at', 'desc')
    .execute();
  
  return fees;
}
