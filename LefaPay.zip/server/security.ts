import { v4 as uuidv4 } from 'uuid';
import { db } from './database.js';
import speakeasy from 'speakeasy';
import qrcode from 'qrcode';
import { Request } from 'express';

export const MAX_LOGIN_ATTEMPTS = 5;
export const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes in milliseconds
export const MAX_ATTEMPTS_PER_IP = 10;
export const IP_LOCKOUT_DURATION = 60 * 60 * 1000; // 1 hour in milliseconds

interface SecurityEvent {
  eventType: string;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
  details?: string;
  status: 'success' | 'failure' | 'warning';
}

export async function logSecurityEvent(event: SecurityEvent) {
  try {
    await db
      .insertInto('security_logs')
      .values({
        id: uuidv4(),
        event_type: event.eventType,
        user_id: event.userId || null,
        ip_address: event.ipAddress || null,
        user_agent: event.userAgent || null,
        details: event.details || null,
        status: event.status,
        created_at: new Date().toISOString()
      })
      .execute();
  } catch (error) {
    console.error('Failed to log security event:', error);
  }
}

export async function recordLoginAttempt(
  email: string,
  ipAddress: string,
  userAgent: string | undefined,
  attemptType: 'admin' | 'business',
  success: boolean
) {
  try {
    await db
      .insertInto('login_attempts')
      .values({
        id: uuidv4(),
        email,
        ip_address: ipAddress,
        user_agent: userAgent || null,
        attempt_type: attemptType,
        success: success ? 1 : 0,
        created_at: new Date().toISOString()
      })
      .execute();
  } catch (error) {
    console.error('Failed to record login attempt:', error);
  }
}

export async function isAccountLocked(email: string): Promise<boolean> {
  const admin = await db
    .selectFrom('admins')
    .select(['failed_login_attempts', 'locked_until'])
    .where('email', '=', email)
    .executeTakeFirst();

  if (!admin) return false;

  if (admin.locked_until) {
    const lockoutExpiry = new Date(admin.locked_until);
    if (new Date() < lockoutExpiry) {
      return true;
    } else {
      // Reset lockout if expired
      await db
        .updateTable('admins')
        .set({
          failed_login_attempts: 0,
          locked_until: null
        })
        .where('email', '=', email)
        .execute();
    }
  }

  return false;
}

export async function isIpBlocked(ipAddress: string): Promise<boolean> {
  const oneHourAgo = new Date(Date.now() - IP_LOCKOUT_DURATION).toISOString();
  
  const attemptCount = await db
    .selectFrom('login_attempts')
    .select(({ fn }) => [fn.count<number>('id').as('count')])
    .where('ip_address', '=', ipAddress)
    .where('success', '=', 0)
    .where('created_at', '>', oneHourAgo)
    .executeTakeFirst();

  return (attemptCount?.count || 0) >= MAX_ATTEMPTS_PER_IP;
}

export async function incrementFailedAttempts(email: string): Promise<void> {
  const admin = await db
    .selectFrom('admins')
    .select(['failed_login_attempts'])
    .where('email', '=', email)
    .executeTakeFirst();

  if (!admin) return;

  const newAttempts = admin.failed_login_attempts + 1;
  const shouldLock = newAttempts >= MAX_LOGIN_ATTEMPTS;

  await db
    .updateTable('admins')
    .set({
      failed_login_attempts: newAttempts,
      locked_until: shouldLock 
        ? new Date(Date.now() + LOCKOUT_DURATION).toISOString()
        : null
    })
    .where('email', '=', email)
    .execute();
}

export async function resetFailedAttempts(email: string): Promise<void> {
  await db
    .updateTable('admins')
    .set({
      failed_login_attempts: 0,
      locked_until: null,
      last_login: new Date().toISOString()
    })
    .where('email', '=', email)
    .execute();
}

export async function isAdminIpWhitelisted(ipAddress: string): Promise<boolean> {
  const whitelist = await db
    .selectFrom('admin_whitelist')
    .select(['id'])
    .where('ip_address', '=', ipAddress)
    .where('active', '=', 1)
    .executeTakeFirst();

  return !!whitelist;
}

export async function generateTwoFactorSecret(adminId: string): Promise<{ secret: string; qrCode: string }> {
  const secret = speakeasy.generateSecret({
    name: 'PayLesotho Admin',
    issuer: 'PayLesotho',
    length: 32
  });

  await db
    .updateTable('admins')
    .set({
      two_factor_secret: secret.base32
    })
    .where('id', '=', adminId)
    .execute();

  const qrCode = await qrcode.toDataURL(secret.otpauth_url!);

  return {
    secret: secret.base32,
    qrCode
  };
}

export async function verifyTwoFactorToken(adminId: string, token: string): Promise<boolean> {
  const admin = await db
    .selectFrom('admins')
    .select(['two_factor_secret'])
    .where('id', '=', adminId)
    .executeTakeFirst();

  if (!admin?.two_factor_secret) return false;

  return speakeasy.totp.verify({
    secret: admin.two_factor_secret,
    encoding: 'base32',
    token,
    window: 2
  });
}

export async function enableTwoFactor(adminId: string): Promise<void> {
  await db
    .updateTable('admins')
    .set({
      two_factor_enabled: 1
    })
    .where('id', '=', adminId)
    .execute();
}

export async function disableTwoFactor(adminId: string): Promise<void> {
  await db
    .updateTable('admins')
    .set({
      two_factor_enabled: 0,
      two_factor_secret: null
    })
    .where('id', '=', adminId)
    .execute();
}

export async function createAdminSession(
  adminId: string,
  ipAddress: string,
  userAgent: string
): Promise<string> {
  const refreshToken = uuidv4();
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

  await db
    .insertInto('admin_sessions')
    .values({
      id: uuidv4(),
      admin_id: adminId,
      refresh_token: refreshToken,
      ip_address: ipAddress,
      user_agent: userAgent,
      expires_at: expiresAt.toISOString(),
      revoked: 0,
      created_at: new Date().toISOString()
    })
    .execute();

  return refreshToken;
}

export async function validateAdminSession(refreshToken: string): Promise<string | null> {
  const session = await db
    .selectFrom('admin_sessions')
    .select(['admin_id', 'expires_at', 'revoked'])
    .where('refresh_token', '=', refreshToken)
    .executeTakeFirst();

  if (!session || session.revoked || new Date() > new Date(session.expires_at)) {
    return null;
  }

  return session.admin_id;
}

export async function revokeAdminSession(refreshToken: string): Promise<void> {
  await db
    .updateTable('admin_sessions')
    .set({ revoked: 1 })
    .where('refresh_token', '=', refreshToken)
    .execute();
}

export async function revokeAllAdminSessions(adminId: string): Promise<void> {
  await db
    .updateTable('admin_sessions')
    .set({ revoked: 1 })
    .where('admin_id', '=', adminId)
    .execute();
}

export function getClientIp(req: Request): string {
  return (
    (req.headers['x-forwarded-for'] as string)?.split(',')[0] ||
    (req.headers['x-real-ip'] as string) ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    '127.0.0.1'
  );
}

export function validatePasswordStrength(password: string): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (password.length < 12) {
    errors.push('Password must be at least 12 characters long');
  }

  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }

  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }

  if (!/\d/.test(password)) {
    errors.push('Password must contain at least one number');
  }

  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }

  // Check for common passwords or patterns
  const commonPasswords = ['password', '123456', 'admin', 'paylesotho'];
  if (commonPasswords.some(common => password.toLowerCase().includes(common))) {
    errors.push('Password contains common words or patterns');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

export async function cleanupExpiredSessions(): Promise<void> {
  await db
    .deleteFrom('admin_sessions')
    .where('expires_at', '<', new Date().toISOString())
    .execute();
}

export async function getSecurityLogs(limit = 100) {
  return await db
    .selectFrom('security_logs')
    .selectAll()
    .orderBy('created_at', 'desc')
    .limit(limit)
    .execute();
}

export async function getLoginAttempts(limit = 100) {
  return await db
    .selectFrom('login_attempts')
    .selectAll()
    .orderBy('created_at', 'desc')
    .limit(limit)
    .execute();
}
