import Database from 'better-sqlite3';
import { Kysely, SqliteDialect } from 'kysely';
import path from 'path';

interface BusinessTable {
  id: string;
  business_name: string;
  email: string;
  password: string;
  business_registration_number: string | null;
  phone: string | null;
  bank_name: string | null;
  bank_account_number: string | null;
  bank_account_name: string | null;
  kyc_status: 'pending' | 'approved' | 'rejected';
  is_active: number; // SQLite stores boolean as number (0/1)
  logo_url: string | null;
  website_url: string | null;
  description: string | null;
  created_at: string;
  updated_at: string;
}

interface PaymentTable {
  id: string;
  business_id: string;
  amount: number;
  currency: string;
  payment_method: string | null;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  customer_email: string | null;
  customer_phone: string | null;
  customer_name: string | null;
  reference: string | null;
  description: string | null;
  redirect_url: string | null;
  created_at: string;
  updated_at: string;
}

interface PaymentLinkTable {
  id: string;
  business_id: string;
  title: string;
  amount: number | null;
  is_fixed_amount: number; // SQLite stores boolean as number (0/1)
  description: string | null;
  redirect_url: string | null;
  is_active: number; // SQLite stores boolean as number (0/1)
  created_at: string;
}

interface AdminTable {
  id: string;
  email: string;
  password: string;
  role: string;
  created_at: string;
}

interface KycDocumentTable {
  id: string;
  business_id: string;
  document_type: string;
  file_url: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

interface TransactionFeeTable {
  id: string;
  payment_id: string;
  business_id: string;
  transaction_amount: number;
  fee_percentage: number;
  fee_amount: number;
  net_amount: number;
  status: 'pending' | 'collected' | 'transferred';
  transferred_at: string | null;
  created_at: string;
}

interface SubscriptionFeeTable {
  id: string;
  business_id: string;
  amount: number;
  currency: string;
  billing_period: string;
  due_date: string;
  paid_date: string | null;
  status: 'pending' | 'paid' | 'overdue';
  payment_method: string | null;
  created_at: string;
  updated_at: string;
}

interface CompanyRevenueTable {
  id: string;
  revenue_type: 'transaction_fee' | 'subscription_fee';
  source_id: string;
  business_id: string;
  amount: number;
  description: string | null;
  transferred_to_bank: number; // SQLite stores boolean as number (0/1)
  transfer_date: string | null;
  created_at: string;
}

interface CompanySettingsTable {
  id: string;
  setting_key: string;
  setting_value: string | null;
  description: string | null;
  created_at: string;
  updated_at: string;
}

interface DatabaseSchema {
  businesses: BusinessTable;
  payments: PaymentTable;
  payment_links: PaymentLinkTable;
  admins: AdminTable;
  kyc_documents: KycDocumentTable;
  transaction_fees: TransactionFeeTable;
  subscription_fees: SubscriptionFeeTable;
  company_revenue: CompanyRevenueTable;
  company_settings: CompanySettingsTable;
}

const dataDirectory = process.env.DATA_DIRECTORY || './data';
const dbPath = path.join(dataDirectory, 'database.sqlite');

console.log('Database path:', dbPath);

const sqliteDb = new Database(dbPath);

export const db = new Kysely<DatabaseSchema>({
  dialect: new SqliteDialect({
    database: sqliteDb,
  }),
  log: ['query', 'error']
});

export type { 
  DatabaseSchema, 
  BusinessTable, 
  PaymentTable, 
  PaymentLinkTable, 
  AdminTable, 
  KycDocumentTable,
  TransactionFeeTable,
  SubscriptionFeeTable,
  CompanyRevenueTable,
  CompanySettingsTable
};
