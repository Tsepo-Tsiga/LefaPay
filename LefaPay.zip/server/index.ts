import express from 'express';
import dotenv from 'dotenv';
import multer from 'multer';
import path from 'path';
import { promises as fs } from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { setupStaticServing } from './static-serve.js';
import { db } from './database.js';
import { 
  hashPassword, 
  comparePassword, 
  generateToken, 
  authenticateBusiness, 
  authenticateAdmin,
  AuthenticatedRequest 
} from './auth.js';
import { 
  calculateAndCreateTransactionFee, 
  createMonthlySubscriptionFee,
  processSubscriptionPayment,
  markRevenueAsTransferred,
  getBusinessTransactionFees,
  getBusinessSubscriptionFees,
  FEE_PERCENTAGE 
} from './fee-management.js';
import {
  getCompanyBankAccount,
  updateCompanyBankAccount,
  validateBankAccountForTransfer
} from './company-settings.js';

dotenv.config();

const app = express();

// Configure multer for file uploads
const dataDirectory = process.env.DATA_DIRECTORY || './data';
const uploadsDir = path.join(dataDirectory, 'uploads');

// Ensure uploads directory exists
async function ensureUploadsDir() {
  try {
    await fs.mkdir(uploadsDir, { recursive: true });
    console.log('Uploads directory ensured:', uploadsDir);
  } catch (error) {
    console.error('Error creating uploads directory:', error);
  }
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only .png, .jpg, .jpeg and .pdf files are allowed!'));
    }
  }
});

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Helper function to get the base URL from request
function getBaseUrl(req: express.Request): string {
  const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:3001';
  return `${protocol}://${host}`;
}

// Business registration endpoint with file upload and payment accounts
app.post('/api/business/register', 
  upload.fields([
    { name: 'ownerIdDocument', maxCount: 1 },
    { name: 'businessAddressProof', maxCount: 1 },
    { name: 'businessRegistrationDoc', maxCount: 1 },
    { name: 'taxClearanceCert', maxCount: 1 }
  ]), 
  async (req: express.Request, res: express.Response) => {
    try {
      const {
        businessName,
        email,
        password,
        phone,
        registrationNumber,
        website,
        description,
        paymentAccounts: paymentAccountsJson
      } = req.body;

      const files = req.files as { [fieldname: string]: Express.Multer.File[] };

      console.log('Business registration attempt:', { email, businessName });
      console.log('Uploaded files:', Object.keys(files || {}));

      // Validate required fields
      if (!businessName || !email || !password) {
        res.status(400).json({ error: 'Business name, email, and password are required' });
        return;
      }

      // Parse and validate payment accounts
      let paymentAccounts;
      try {
        paymentAccounts = JSON.parse(paymentAccountsJson || '[]');
        if (!Array.isArray(paymentAccounts) || paymentAccounts.length === 0) {
          res.status(400).json({ error: 'At least one payment account is required' });
          return;
        }
      } catch (err) {
        res.status(400).json({ error: 'Invalid payment accounts data' });
        return;
      }

      // Validate required documents
      const requiredDocs = ['ownerIdDocument', 'businessAddressProof', 'businessRegistrationDoc', 'taxClearanceCert'];
      for (const docType of requiredDocs) {
        if (!files || !files[docType] || files[docType].length === 0) {
          res.status(400).json({ error: `${docType} is required` });
          return;
        }
      }

      // Check if business already exists
      const existingBusiness = await db
        .selectFrom('businesses')
        .selectAll()
        .where('email', '=', email)
        .executeTakeFirst();

      if (existingBusiness) {
        res.status(400).json({ error: 'Business with this email already exists' });
        return;
      }

      // Hash password
      const hashedPassword = hashPassword(password);

      // Create business
      const businessId = uuidv4();
      await db
        .insertInto('businesses')
        .values({
          id: businessId,
          business_name: businessName,
          email,
          password: hashedPassword,
          phone: phone || null,
          business_registration_number: registrationNumber || null,
          bank_name: null, // Legacy field, now using payment_accounts table
          bank_account_number: null, // Legacy field
          bank_account_name: null, // Legacy field
          website_url: website || null,
          description: description || null,
          kyc_status: 'pending',
          is_active: 0,
          payment_accounts_completed: 1, // Marked as completed since we're adding accounts
          profile_completion_percentage: 80, // Higher since payment accounts are included
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .execute();

      // Store payment accounts
      for (const account of paymentAccounts) {
        const accountId = uuidv4();
        await db
          .insertInto('business_payment_accounts')
          .values({
            id: accountId,
            business_id: businessId,
            account_type: account.accountType,
            account_name: account.accountName,
            provider_name: account.providerName,
            account_number: account.accountNumber,
            account_holder_name: account.accountHolderName,
            branch_code: account.branchCode || null,
            swift_code: account.swiftCode || null,
            is_primary: account.isPrimary ? 1 : 0,
            is_active: 1,
            verification_status: 'pending',
            verification_notes: null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          })
          .execute();
        
        console.log('Payment account stored:', account.accountType, account.accountName);
      }

      // Store KYC documents
      const documentTypes = {
        ownerIdDocument: 'owner_id',
        businessAddressProof: 'address_proof',
        businessRegistrationDoc: 'registration_document',
        taxClearanceCert: 'tax_clearance'
      };

      for (const [fieldName, docType] of Object.entries(documentTypes)) {
        if (files[fieldName] && files[fieldName][0]) {
          const file = files[fieldName][0];
          const docId = uuidv4();
          
          await db
            .insertInto('kyc_documents')
            .values({
              id: docId,
              business_id: businessId,
              document_type: docType,
              file_url: file.path,
              status: 'pending',
              created_at: new Date().toISOString()
            })
            .execute();
          
          console.log('KYC document stored:', docType, file.filename);
        }
      }

      // Create first monthly subscription fee
      await createMonthlySubscriptionFee(businessId);

      console.log('Business registered successfully:', businessId);

      res.status(201).json({ 
        message: 'Business registered successfully. Your documents and payment accounts are being reviewed.',
        businessId 
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
);

// Business login endpoint
app.post('/api/business/login', async (req: express.Request, res: express.Response) => {
  try {
    const { email, password } = req.body;

    console.log('Business login attempt:', email);

    // Find business
    const business = await db
      .selectFrom('businesses')
      .selectAll()
      .where('email', '=', email)
      .executeTakeFirst();

    if (!business || !comparePassword(password, business.password)) {
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    // Check if account is active
    if (!business.is_active) {
      res.status(403).json({ error: 'Account is deactivated. Please contact support.' });
      return;
    }

    // Generate token
    const token = generateToken({
      id: business.id,
      email: business.email,
      businessName: business.business_name
    });

    console.log('Business login successful:', business.id);

    res.json({ 
      token,
      business: {
        id: business.id,
        businessName: business.business_name,
        email: business.email,
        kycStatus: business.kyc_status
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Business profile endpoint
app.get('/api/business/profile', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const business = await db
      .selectFrom('businesses')
      .select([
        'id',
        'business_name',
        'email',
        'kyc_status',
        'is_active',
        'phone',
        'website_url',
        'description',
        'payment_accounts_completed',
        'profile_completion_percentage'
      ])
      .where('id', '=', req.business!.id)
      .executeTakeFirst();

    if (!business) {
      res.status(404).json({ error: 'Business not found' });
      return;
    }

    res.json({
      ...business,
      is_active: Boolean(business.is_active),
      payment_accounts_completed: Boolean(business.payment_accounts_completed)
    });
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Business payment accounts endpoint
app.get('/api/business/payment-accounts', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const accounts = await db
      .selectFrom('business_payment_accounts')
      .selectAll()
      .where('business_id', '=', req.business!.id)
      .where('is_active', '=', 1)
      .orderBy('is_primary', 'desc')
      .orderBy('created_at', 'asc')
      .execute();

    const convertedAccounts = accounts.map(account => ({
      ...account,
      is_primary: Boolean(account.is_primary),
      is_active: Boolean(account.is_active)
    }));

    res.json(convertedAccounts);
  } catch (error) {
    console.error('Payment accounts fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add payment account endpoint
app.post('/api/business/payment-accounts', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const {
      accountType,
      accountName,
      providerName,
      accountNumber,
      accountHolderName,
      branchCode,
      swiftCode,
      isPrimary
    } = req.body;

    // Validate required fields
    if (!accountType || !accountName || !providerName || !accountNumber || !accountHolderName) {
      res.status(400).json({ error: 'All account fields are required except branch code and swift code' });
      return;
    }

    // If this is set as primary, unset other primary accounts
    if (isPrimary) {
      await db
        .updateTable('business_payment_accounts')
        .set({ is_primary: 0, updated_at: new Date().toISOString() })
        .where('business_id', '=', req.business!.id)
        .execute();
    }

    const accountId = uuidv4();
    await db
      .insertInto('business_payment_accounts')
      .values({
        id: accountId,
        business_id: req.business!.id,
        account_type: accountType,
        account_name: accountName,
        provider_name: providerName,
        account_number: accountNumber,
        account_holder_name: accountHolderName,
        branch_code: branchCode || null,
        swift_code: swiftCode || null,
        is_primary: isPrimary ? 1 : 0,
        is_active: 1,
        verification_status: 'pending',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .execute();

    console.log('Payment account added:', accountId);

    res.status(201).json({ 
      message: 'Payment account added successfully',
      accountId 
    });
  } catch (error) {
    console.error('Add payment account error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Business payments endpoint
app.get('/api/business/payments', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const payments = await db
      .selectFrom('payments')
      .selectAll()
      .where('business_id', '=', req.business!.id)
      .orderBy('created_at', 'desc')
      .execute();

    res.json(payments);
  } catch (error) {
    console.error('Payments fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Business transaction fees endpoint
app.get('/api/business/fees/transactions', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const fees = await getBusinessTransactionFees(req.business!.id);
    res.json(fees);
  } catch (error) {
    console.error('Transaction fees fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Business subscription fees endpoint
app.get('/api/business/fees/subscriptions', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const fees = await getBusinessSubscriptionFees(req.business!.id);
    res.json(fees);
  } catch (error) {
    console.error('Subscription fees fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pay subscription fee endpoint
app.post('/api/business/fees/subscriptions/:subscriptionId/pay', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const { subscriptionId } = req.params;
    const { paymentMethod } = req.body;

    // Verify subscription belongs to business
    const subscription = await db
      .selectFrom('subscription_fees')
      .selectAll()
      .where('id', '=', subscriptionId)
      .where('business_id', '=', req.business!.id)
      .executeTakeFirst();

    if (!subscription) {
      res.status(404).json({ error: 'Subscription not found' });
      return;
    }

    if (subscription.status === 'paid') {
      res.status(400).json({ error: 'Subscription already paid' });
      return;
    }

    const revenueId = await processSubscriptionPayment(subscriptionId, paymentMethod);

    res.json({ 
      message: 'Subscription fee paid successfully',
      revenueId 
    });
  } catch (error) {
    console.error('Subscription payment error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Business payment links endpoint
app.get('/api/business/payment-links', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const paymentLinks = await db
      .selectFrom('payment_links')
      .selectAll()
      .where('business_id', '=', req.business!.id)
      .orderBy('created_at', 'desc')
      .execute();

    // Convert boolean values for response
    const convertedLinks = paymentLinks.map(link => ({
      ...link,
      is_fixed_amount: Boolean(link.is_fixed_amount),
      is_active: Boolean(link.is_active)
    }));

    res.json(convertedLinks);
  } catch (error) {
    console.error('Payment links fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create payment link endpoint
app.post('/api/business/payment-links', authenticateBusiness, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const { title, amount, isFixedAmount, description, redirectUrl } = req.body;

    const linkId = uuidv4();
    await db
      .insertInto('payment_links')
      .values({
        id: linkId,
        business_id: req.business!.id,
        title,
        amount: isFixedAmount ? amount : null,
        is_fixed_amount: isFixedAmount ? 1 : 0, // Convert boolean to number
        description: description || null,
        redirect_url: redirectUrl || null,
        is_active: 1, // Convert boolean to number
        created_at: new Date().toISOString()
      })
      .execute();

    console.log('Payment link created:', linkId);

    // Generate the payment URL using the current request's base URL
    const baseUrl = getBaseUrl(req);
    const paymentUrl = `${baseUrl}/pay/${linkId}`;

    res.status(201).json({ 
      message: 'Payment link created successfully',
      linkId,
      url: paymentUrl
    });
  } catch (error) {
    console.error('Payment link creation error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get payment link for public access
app.get('/api/payment-links/:linkId', async (req: express.Request, res: express.Response) => {
  try {
    const { linkId } = req.params;

    const paymentLink = await db
      .selectFrom('payment_links')
      .leftJoin('businesses', 'payment_links.business_id', 'businesses.id')
      .select([
        'payment_links.id',
        'payment_links.title',
        'payment_links.amount',
        'payment_links.is_fixed_amount',
        'payment_links.description',
        'payment_links.redirect_url',
        'businesses.business_name',
        'businesses.logo_url',
        'businesses.is_active'
      ])
      .where('payment_links.id', '=', linkId)
      .where('payment_links.is_active', '=', 1) // Use number instead of boolean
      .executeTakeFirst();

    if (!paymentLink) {
      res.status(404).json({ error: 'Payment link not found' });
      return;
    }

    // Check if business account is active
    if (!paymentLink.is_active) {
      res.status(403).json({ error: 'This business account is currently inactive' });
      return;
    }

    res.json({
      id: paymentLink.id,
      title: paymentLink.title,
      amount: paymentLink.amount,
      is_fixed_amount: Boolean(paymentLink.is_fixed_amount), // Convert to boolean for response
      description: paymentLink.description,
      feePercentage: FEE_PERCENTAGE,
      business: {
        business_name: paymentLink.business_name,
        logo_url: paymentLink.logo_url
      }
    });
  } catch (error) {
    console.error('Payment link fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Process payment endpoint
app.post('/api/payments/process', async (req: express.Request, res: express.Response) => {
  try {
    const { paymentLinkId, amount, customerName, customerEmail, customerPhone, paymentMethod, cardDetails } = req.body;

    // Get payment link details
    const paymentLink = await db
      .selectFrom('payment_links')
      .leftJoin('businesses', 'payment_links.business_id', 'businesses.id')
      .select([
        'payment_links.id',
        'payment_links.business_id',
        'payment_links.amount',
        'payment_links.is_fixed_amount',
        'payment_links.description',
        'payment_links.redirect_url',
        'businesses.is_active'
      ])
      .where('payment_links.id', '=', paymentLinkId)
      .where('payment_links.is_active', '=', 1) // Use number instead of boolean
      .executeTakeFirst();

    if (!paymentLink) {
      res.status(404).json({ error: 'Payment link not found' });
      return;
    }

    // Check if business account is active
    if (!paymentLink.is_active) {
      res.status(403).json({ error: 'This business account is currently inactive' });
      return;
    }

    // Validate amount for fixed amount links
    if (paymentLink.is_fixed_amount && amount !== paymentLink.amount) {
      res.status(400).json({ error: 'Invalid payment amount' });
      return;
    }

    // Validate card details if payment method is card
    if (paymentMethod === 'card') {
      if (!cardDetails || !cardDetails.cardNumber || !cardDetails.expiryDate || !cardDetails.cvv || !cardDetails.cardHolderName) {
        res.status(400).json({ error: 'Missing card details' });
        return;
      }
      console.log('Card payment processed for:', cardDetails.cardHolderName, 'ending in', cardDetails.cardNumber.slice(-4));
    }

    // Create payment record
    const paymentId = uuidv4();
    
    // For demo purposes, simulate successful card processing
    const paymentStatus = paymentMethod === 'card' ? 'completed' : 'pending';
    
    await db
      .insertInto('payments')
      .values({
        id: paymentId,
        business_id: paymentLink.business_id,
        amount: amount,
        currency: 'LSL',
        payment_method: paymentMethod,
        status: paymentStatus,
        customer_name: customerName,
        customer_email: customerEmail,
        customer_phone: customerPhone || null,
        reference: paymentId.slice(0, 8).toUpperCase(),
        description: paymentLink.description,
        redirect_url: paymentLink.redirect_url,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .execute();

    // Calculate and create transaction fee for completed payments
    let feeInfo = null;
    if (paymentStatus === 'completed') {
      feeInfo = await calculateAndCreateTransactionFee(paymentId, paymentLink.business_id, amount);
    }

    console.log('Payment initiated:', paymentId, 'Status:', paymentStatus);
    if (feeInfo) {
      console.log('Transaction fee calculated:', feeInfo.feeAmount, 'Net amount:', feeInfo.netAmount);
    }

    // In a real implementation, this would integrate with payment processors
    // For now, we'll simulate payment processing
    res.json({
      paymentId,
      status: paymentStatus,
      message: paymentMethod === 'card' 
        ? 'Card payment processed successfully!'
        : 'Payment initiated successfully',
      feeInfo: feeInfo ? {
        feeAmount: feeInfo.feeAmount,
        netAmount: feeInfo.netAmount,
        feePercentage: FEE_PERCENTAGE
      } : null,
      instructions: getPaymentInstructions(paymentMethod, amount, feeInfo?.netAmount)
    });
  } catch (error) {
    console.error('Payment processing error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin login endpoint  
app.post('/api/admin/login', async (req: express.Request, res: express.Response) => {
  try {
    const { email, password } = req.body;

    console.log('Admin login attempt:', email);

    // For demo purposes, create a default admin if none exists
    let admin = await db
      .selectFrom('admins')
      .selectAll()
      .where('email', '=', email)
      .executeTakeFirst();

    if (!admin && email === 'tsepo.moholoholo22@gmail.com') {
      const adminId = uuidv4();
      const hashedPassword = hashPassword('T$m59512707');
      
      await db
        .insertInto('admins')
        .values({
          id: adminId,
          email: 'tsepo.moholoholo22@gmail.com',
          password: hashedPassword,
          role: 'admin',
          created_at: new Date().toISOString()
        })
        .execute();

      admin = { id: adminId, email, password: hashedPassword, role: 'admin', created_at: new Date().toISOString() };
      console.log('Default admin account created:', email);
    }

    if (!admin || !comparePassword(password, admin.password)) {
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    const token = generateToken({
      id: admin.id,
      email: admin.email,
      role: admin.role
    });

    console.log('Admin login successful:', admin.id);

    res.json({ token });
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin businesses endpoint
app.get('/api/admin/businesses', authenticateAdmin, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const businesses = await db
      .selectFrom('businesses')
      .select([
        'id',
        'business_name',
        'email',
        'kyc_status',
        'is_active',
        'payment_accounts_completed',
        'profile_completion_percentage',
        'created_at'
      ])
      .orderBy('created_at', 'desc')
      .execute();

    // Convert boolean values for response
    const convertedBusinesses = businesses.map(business => ({
      ...business,
      is_active: Boolean(business.is_active),
      payment_accounts_completed: Boolean(business.payment_accounts_completed)
    }));

    res.json(convertedBusinesses);
  } catch (error) {
    console.error('Admin businesses fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin stats endpoint
app.get('/api/admin/stats', authenticateAdmin, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const [businessCount, pendingKyc, paymentStats, revenueStats] = await Promise.all([
      db.selectFrom('businesses').select(({ fn }) => [fn.count<number>('id').as('count')]).executeTakeFirst(),
      db.selectFrom('businesses').select(({ fn }) => [fn.count<number>('id').as('count')]).where('kyc_status', '=', 'pending').executeTakeFirst(),
      db.selectFrom('payments').select(({ fn }) => [
        fn.count<number>('id').as('totalPayments'),
        fn.sum<number>('amount').as('totalVolume')
      ]).executeTakeFirst(),
      db.selectFrom('company_revenue').select(({ fn }) => [
        fn.sum<number>('amount').as('totalRevenue'),
        fn.count<number>('id').as('revenueTransactions')
      ]).executeTakeFirst()
    ]);

    res.json({
      totalBusinesses: businessCount?.count || 0,
      pendingKyc: pendingKyc?.count || 0,
      totalPayments: paymentStats?.totalPayments || 0,
      totalVolume: paymentStats?.totalVolume || 0,
      companyRevenue: revenueStats?.totalRevenue || 0,
      revenueTransactions: revenueStats?.revenueTransactions || 0
    });
  } catch (error) {
    console.error('Admin stats fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin revenue endpoint
app.get('/api/admin/revenue', authenticateAdmin, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const revenue = await db
      .selectFrom('company_revenue')
      .leftJoin('businesses', 'company_revenue.business_id', 'businesses.id')
      .select([
        'company_revenue.id',
        'company_revenue.revenue_type',
        'company_revenue.amount',
        'company_revenue.description',
        'company_revenue.transferred_to_bank',
        'company_revenue.transfer_date',
        'company_revenue.created_at',
        'businesses.business_name'
      ])
      .orderBy('company_revenue.created_at', 'desc')
      .execute();

    const convertedRevenue = revenue.map(rev => ({
      ...rev,
      transferred_to_bank: Boolean(rev.transferred_to_bank)
    }));

    res.json(convertedRevenue);
  } catch (error) {
    console.error('Admin revenue fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin bank account endpoints
app.get('/api/admin/bank-account', authenticateAdmin, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const bankAccount = await getCompanyBankAccount();
    res.json(bankAccount);
  } catch (error) {
    console.error('Bank account fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/admin/bank-account', authenticateAdmin, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const { bankName, accountNumber, accountHolder, bankBranch, swiftCode } = req.body;

    if (!bankName || !accountNumber || !accountHolder) {
      res.status(400).json({ error: 'Bank name, account number, and account holder name are required' });
      return;
    }

    await updateCompanyBankAccount({
      bankName,
      accountNumber,
      accountHolder,
      bankBranch: bankBranch || null,
      swiftCode: swiftCode || null
    });

    res.json({ message: 'Bank account details updated successfully' });
  } catch (error) {
    console.error('Bank account update error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin transfer revenue endpoint
app.post('/api/admin/revenue/transfer', authenticateAdmin, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const { revenueIds } = req.body;

    if (!revenueIds || !Array.isArray(revenueIds) || revenueIds.length === 0) {
      res.status(400).json({ error: 'Invalid revenue IDs' });
      return;
    }

    // Validate that bank account is configured
    const validation = await validateBankAccountForTransfer();
    if (!validation.isValid) {
      res.status(400).json({ 
        error: 'Bank account not configured',
        message: `Please configure your bank account before transferring funds. Missing: ${validation.missingFields.join(', ')}`,
        missingFields: validation.missingFields
      });
      return;
    }

    await markRevenueAsTransferred(revenueIds);

    res.json({ 
      message: 'Revenue transferred to PayLesotho bank account successfully',
      transferredCount: revenueIds.length
    });
  } catch (error) {
    console.error('Revenue transfer error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin KYC action endpoint
app.put('/api/admin/businesses/:businessId/kyc', authenticateAdmin, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const { businessId } = req.params;
    const { action } = req.body;

    if (!['approve', 'reject'].includes(action)) {
      res.status(400).json({ error: 'Invalid action' });
      return;
    }

    const kycStatus = action === 'approve' ? 'approved' : 'rejected';
    const isActive = action === 'approve' ? 1 : 0; // Convert boolean to number

    await db
      .updateTable('businesses')
      .set({
        kyc_status: kycStatus,
        is_active: isActive,
        profile_completion_percentage: action === 'approve' ? 100 : 50,
        updated_at: new Date().toISOString()
      })
      .where('id', '=', businessId)
      .execute();

    console.log(`Business ${businessId} KYC ${action}d`);

    res.json({ message: `Business ${action}d successfully` });
  } catch (error) {
    console.error('KYC action error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin account status action endpoint
app.put('/api/admin/businesses/:businessId/status', authenticateAdmin, async (req: AuthenticatedRequest, res: express.Response) => {
  try {
    const { businessId } = req.params;
    const { action } = req.body;

    if (!['activate', 'deactivate'].includes(action)) {
      res.status(400).json({ error: 'Invalid action' });
      return;
    }

    const isActive = action === 'activate' ? 1 : 0; // Convert boolean to number

    await db
      .updateTable('businesses')
      .set({
        is_active: isActive,
        updated_at: new Date().toISOString()
      })
      .where('id', '=', businessId)
      .execute();

    console.log(`Business ${businessId} ${action}d`);

    res.json({ message: `Business ${action}d successfully` });
  } catch (error) {
    console.error('Account status action error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

function getPaymentInstructions(paymentMethod: string, amount: number, netAmount?: number): string {
  const feeInfo = netAmount ? ` (You will receive LSL ${netAmount.toFixed(2)} after our 5.7% processing fee)` : '';
  
  switch (paymentMethod) {
    case 'mpesa':
      return `Send LSL ${amount.toFixed(2)} via M-Pesa to our merchant number. You will receive an SMS confirmation.${feeInfo}`;
    case 'ecocash':
      return `Send LSL ${amount.toFixed(2)} via EcoCash to our merchant number. You will receive an SMS confirmation.${feeInfo}`;
    case 'card':
      return `Your card payment of LSL ${amount.toFixed(2)} has been processed successfully. A confirmation email will be sent shortly.${feeInfo}`;
    case 'bank':
      return `Please transfer LSL ${amount.toFixed(2)} to our bank account. Reference number will be provided via email.${feeInfo}`;
    default:
      return `Please complete your LSL ${amount.toFixed(2)} payment using the selected method.${feeInfo}`;
  }
}

// Export a function to start the server
export async function startServer(port) {
  try {
    // Ensure uploads directory exists
    await ensureUploadsDir();
    
    if (process.env.NODE_ENV === 'production') {
      await setupStaticServing(app);
    }
    app.listen(port, () => {
      console.log(`API Server running on port ${port}`);
      console.log(`Admin login: tsepo.moholoholo22@gmail.com / T$m59512707`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

// Start the server directly if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('Starting server...');
  startServer(process.env.PORT || 3001);
}
