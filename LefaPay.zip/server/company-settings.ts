import { db } from './database.js';

export interface CompanyBankAccount {
  bankName: string | null;
  accountNumber: string | null;
  accountHolder: string | null;
  bankBranch: string | null;
  swiftCode: string | null;
}

export async function getCompanyBankAccount(): Promise<CompanyBankAccount> {
  console.log('Fetching company bank account settings');
  
  const settings = await db
    .selectFrom('company_settings')
    .select(['setting_key', 'setting_value'])
    .where('setting_key', 'in', [
      'company_bank_name',
      'company_bank_account', 
      'company_account_holder',
      'company_bank_branch',
      'company_swift_code'
    ])
    .execute();

  const settingsMap = settings.reduce((acc, setting) => {
    acc[setting.setting_key] = setting.setting_value;
    return acc;
  }, {} as Record<string, string | null>);

  return {
    bankName: settingsMap['company_bank_name'] || null,
    accountNumber: settingsMap['company_bank_account'] || null,
    accountHolder: settingsMap['company_account_holder'] || null,
    bankBranch: settingsMap['company_bank_branch'] || null,
    swiftCode: settingsMap['company_swift_code'] || null
  };
}

export async function updateCompanyBankAccount(bankAccount: CompanyBankAccount): Promise<void> {
  console.log('Updating company bank account settings');
  
  const updates = [
    { key: 'company_bank_name', value: bankAccount.bankName },
    { key: 'company_bank_account', value: bankAccount.accountNumber },
    { key: 'company_account_holder', value: bankAccount.accountHolder },
    { key: 'company_bank_branch', value: bankAccount.bankBranch },
    { key: 'company_swift_code', value: bankAccount.swiftCode }
  ];

  for (const update of updates) {
    await db
      .updateTable('company_settings')
      .set({
        setting_value: update.value,
        updated_at: new Date().toISOString()
      })
      .where('setting_key', '=', update.key)
      .execute();
  }

  console.log('Company bank account settings updated successfully');
}

export async function isCompanyBankAccountConfigured(): Promise<boolean> {
  const bankAccount = await getCompanyBankAccount();
  
  // Check if all required fields are filled
  const isConfigured = !!(
    bankAccount.bankName &&
    bankAccount.accountNumber &&
    bankAccount.accountHolder
  );

  console.log('Company bank account configured:', isConfigured);
  return isConfigured;
}

export async function validateBankAccountForTransfer(): Promise<{ isValid: boolean; missingFields: string[] }> {
  const bankAccount = await getCompanyBankAccount();
  const missingFields: string[] = [];

  if (!bankAccount.bankName) missingFields.push('Bank Name');
  if (!bankAccount.accountNumber) missingFields.push('Account Number');
  if (!bankAccount.accountHolder) missingFields.push('Account Holder Name');

  return {
    isValid: missingFields.length === 0,
    missingFields
  };
}
