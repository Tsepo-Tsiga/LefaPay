import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

interface CreatePaymentLinkDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function CreatePaymentLinkDialog({ open, onOpenChange, onSuccess }: CreatePaymentLinkDialogProps) {
  const [formData, setFormData] = React.useState({
    title: '',
    amount: '',
    description: '',
    redirectUrl: '',
    isFixedAmount: true
  });
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState('');

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const token = localStorage.getItem('businessToken');
      const response = await fetch('/api/business/payment-links', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          title: formData.title,
          amount: formData.isFixedAmount ? parseFloat(formData.amount) : null,
          isFixedAmount: formData.isFixedAmount,
          description: formData.description,
          redirectUrl: formData.redirectUrl || null
        }),
      });

      const data = await response.json();

      if (response.ok) {
        onSuccess();
        onOpenChange(false);
        setFormData({
          title: '',
          amount: '',
          description: '',
          redirectUrl: '',
          isFixedAmount: true
        });
        
        // Show success message with the correct payment URL
        alert(`Payment link created successfully! Share this link: ${data.url}`);
      } else {
        setError(data.error || 'Failed to create payment link');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create Payment Link</DialogTitle>
          <DialogDescription>
            Create a new payment link to share with your customers
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            {error && (
              <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                <p className="text-destructive text-sm">{error}</p>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                placeholder="e.g., Product Purchase, Service Payment"
                required
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="fixedAmount"
                checked={formData.isFixedAmount}
                onCheckedChange={(checked) => handleInputChange('isFixedAmount', checked)}
              />
              <Label htmlFor="fixedAmount">Fixed Amount</Label>
            </div>

            {formData.isFixedAmount && (
              <div className="space-y-2">
                <Label htmlFor="amount">Amount (LSL) *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => handleInputChange('amount', e.target.value)}
                  placeholder="0.00"
                  required
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Brief description of the payment"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="redirectUrl">Redirect URL (Optional)</Label>
              <Input
                id="redirectUrl"
                type="url"
                value={formData.redirectUrl}
                onChange={(e) => handleInputChange('redirectUrl', e.target.value)}
                placeholder="https://your-website.com/thank-you"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Creating...' : 'Create Link'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
