import * as React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HomePage } from './pages/HomePage';
import { BusinessSignupPage } from './pages/BusinessSignupPage';
import { BusinessLoginPage } from './pages/BusinessLoginPage';
import { BusinessDashboardPage } from './pages/BusinessDashboardPage';
import { SalesReportsPage } from './pages/SalesReportsPage';
import { FeesPage } from './pages/FeesPage';
import { PaymentAccountsPage } from './pages/PaymentAccountsPage';
import { PaymentPage } from './pages/PaymentPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminRevenuePage } from './pages/AdminRevenuePage';
import { AdminBankAccountPage } from './pages/AdminBankAccountPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-background">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/business/signup" element={<BusinessSignupPage />} />
          <Route path="/business/login" element={<BusinessLoginPage />} />
          <Route path="/business/dashboard" element={<BusinessDashboardPage />} />
          <Route path="/business/reports" element={<SalesReportsPage />} />
          <Route path="/business/fees" element={<FeesPage />} />
          <Route path="/business/payment-accounts" element={<PaymentAccountsPage />} />
          <Route path="/pay/:linkId" element={<PaymentPage />} />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
          <Route path="/admin/revenue" element={<AdminRevenuePage />} />
          <Route path="/admin/bank-account" element={<AdminBankAccountPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
