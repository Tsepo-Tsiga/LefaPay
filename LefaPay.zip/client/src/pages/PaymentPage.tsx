import * as React from 'react';
import { useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, Smartphone, Building2 } from 'lucide-react';

interface PaymentLink {
  id: string;
  title: string;
  amount: number | null;
  is_fixed_amount: boolean;
  description: string | null;
  feePercentage: number;
  business: {
    business_name: string;
    logo_url: string | null;
  };
}

export function PaymentPage() {
  const { linkId } = useParams();
  const [paymentLink, setPaymentLink] = React.useState<PaymentLink | null>(null);
  const [formData, setFormData] = React.useState({
    amount: '',
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    paymentMethod: ''
  });
  const [cardDetails, setCardDetails] = React.useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardHolderName: ''
  });
  const [isLoading, setIsLoading] = React.useState(true);
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [error, setError] = React.useState('');
  const [success, setSuccess] = React.useState('');

  React.useEffect(() => {
    const fetchPaymentLink = async () => {
      try {
        const response = await fetch(`/api/payment-links/${linkId}`);
        const data = await response.json();

        if (response.ok) {
          setPaymentLink(data);
          if (data.is_fixed_amount) {
            setFormData(prev => ({ ...prev, amount: data.amount.toString() }));
          }
        } else {
          setError(data.error || 'Payment link not found');
        }
      } catch (err) {
        setError('Network error. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };

    if (linkId) {
      fetchPaymentLink();
    }
  }, [linkId]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCardChange = (field: string, value: string) => {
    setCardDetails(prev => ({ ...prev, [field]: value }));
  };

  const calculateFee = (amount: number) => {
    return (amount * (paymentLink?.feePercentage || 0)) / 100;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setError('');
    setSuccess('');

    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid amount');
      setIsProcessing(false);
      return;
    }

    try {
      const response = await fetch('/api/payments/process', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          paymentLinkId: linkId,
          amount,
          customerName: formData.customerName,
          customerEmail: formData.customerEmail,
          customerPhone: formData.customerPhone,
          paymentMethod: formData.paymentMethod,
          cardDetails: formData.paymentMethod === 'card' ? cardDetails : undefined
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess(`${data.message}\n\n${data.instructions}`);
      } else {
        setError(data.error || 'Payment processing failed');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <CreditCard className="w-12 h-12 text-primary mx-auto mb-4" />
          <p>Loading payment details...</p>
        </div>
      </div>
    );
  }

  if (error && !paymentLink) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-8">
            <p className="text-destructive">{error}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const amount = parseFloat(formData.amount) || 0;
  const fee = calculateFee(amount);
  const total = amount + fee;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground py-6">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <CreditCard className="w-8 h-8" />
            <h1 className="text-2xl font-bold">PayLesotho</h1>
          </div>
          <p className="text-primary-foreground/80">Secure Payment Processing</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {paymentLink && (
            <Card className="mb-6">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>{paymentLink.title}</CardTitle>
                    <CardDescription>{paymentLink.business.business_name}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              {paymentLink.description && (
                <CardContent>
                  <p className="text-muted-foreground">{paymentLink.description}</p>
                </CardContent>
              )}
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Payment Details</CardTitle>
              <CardDescription>Complete your payment securely</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {error && (
                  <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                    <p className="text-destructive text-sm">{error}</p>
                  </div>
                )}

                {success && (
                  <div className="p-3 bg-accent/10 border border-accent/20 rounded-md">
                    <p className="text-accent text-sm whitespace-pre-line">{success}</p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="amount">Amount (LSL) *</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.amount}
                    onChange={(e) => handleInputChange('amount', e.target.value)}
                    disabled={paymentLink?.is_fixed_amount}
                    required
                  />
                  {amount > 0 && (
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span>Amount:</span>
                        <span>LSL {amount.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-muted-foreground">
                        <span>Processing fee ({paymentLink?.feePercentage}%):</span>
                        <span>LSL {fee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-medium border-t pt-1">
                        <span>Total:</span>
                        <span>LSL {total.toFixed(2)}</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="customerName">Full Name *</Label>
                    <Input
                      id="customerName"
                      value={formData.customerName}
                      onChange={(e) => handleInputChange('customerName', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerEmail">Email Address *</Label>
                    <Input
                      id="customerEmail"
                      type="email"
                      value={formData.customerEmail}
                      onChange={(e) => handleInputChange('customerEmail', e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="customerPhone">Phone Number</Label>
                  <Input
                    id="customerPhone"
                    value={formData.customerPhone}
                    onChange={(e) => handleInputChange('customerPhone', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="paymentMethod">Payment Method *</Label>
                  <Select value={formData.paymentMethod} onValueChange={(value) => handleInputChange('paymentMethod', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="card">
                        <div className="flex items-center space-x-2">
                          <CreditCard className="w-4 h-4" />
                          <span>Credit/Debit Card</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="mpesa">
                        <div className="flex items-center space-x-2">
                          <Smartphone className="w-4 h-4" />
                          <span>M-Pesa</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="ecocash">
                        <div className="flex items-center space-x-2">
                          <Smartphone className="w-4 h-4" />
                          <span>EcoCash</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="bank">
                        <div className="flex items-center space-x-2">
                          <Building2 className="w-4 h-4" />
                          <span>Bank Transfer</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formData.paymentMethod === 'card' && (
                  <div className="space-y-4 p-4 border rounded-lg">
                    <h4 className="font-medium">Card Details</h4>
                    <div className="space-y-2">
                      <Label htmlFor="cardNumber">Card Number *</Label>
                      <Input
                        id="cardNumber"
                        value={cardDetails.cardNumber}
                        onChange={(e) => handleCardChange('cardNumber', e.target.value)}
                        placeholder="1234 5678 9012 3456"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="expiryDate">Expiry Date *</Label>
                        <Input
                          id="expiryDate"
                          value={cardDetails.expiryDate}
                          onChange={(e) => handleCardChange('expiryDate', e.target.value)}
                          placeholder="MM/YY"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cvv">CVV *</Label>
                        <Input
                          id="cvv"
                          value={cardDetails.cvv}
                          onChange={(e) => handleCardChange('cvv', e.target.value)}
                          placeholder="123"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cardHolderName">Cardholder Name *</Label>
                      <Input
                        id="cardHolderName"
                        value={cardDetails.cardHolderName}
                        onChange={(e) => handleCardChange('cardHolderName', e.target.value)}
                        required
                      />
                    </div>
                  </div>
                )}

                <Button type="submit" className="w-full" disabled={isProcessing || !formData.paymentMethod}>
                  {isProcessing ? 'Processing...' : `Pay LSL ${total.toFixed(2)}`}
                </Button>

                <div className="text-center text-sm text-muted-foreground">
                  <p>Secured by PayLesotho • Your payment information is encrypted</p>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
