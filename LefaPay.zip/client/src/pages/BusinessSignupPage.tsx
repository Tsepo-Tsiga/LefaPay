import * as React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft,
  CreditCard,
  Upload,
  FileText,
  Plus,
  Trash2,
  Banknote,
  Smartphone,
} from "lucide-react";

interface PaymentAccount {
  id: string;
  accountType: "bank_account" | "mobile_money";
  accountName: string;
  providerName: string;
  accountNumber: string;
  accountHolderName: string;
  branchCode?: string;
  swiftCode?: string;
  isPrimary: boolean;
}

export function BusinessSignupPage() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = React.useState(1);
  const [formData, setFormData] = React.useState({
    businessName: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    registrationNumber: "",
    website: "",
    description: "",
  });
  const [paymentAccounts, setPaymentAccounts] = React.useState<
    PaymentAccount[]
  >([]);
  const [documents, setDocuments] = React.useState({
    ownerIdDocument: null as File | null,
    businessAddressProof: null as File | null,
    businessRegistrationDoc: null as File | null,
    taxClearanceCert: null as File | null,
  });
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState("");

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleDocumentChange = (field: string, file: File | null) => {
    setDocuments((prev) => ({ ...prev, [field]: file }));
  };

  const addPaymentAccount = (type: "bank_account" | "mobile_money") => {
    const newAccount: PaymentAccount = {
      id: Date.now().toString(),
      accountType: type,
      accountName: "",
      providerName: "",
      accountNumber: "",
      accountHolderName: formData.businessName,
      branchCode: "",
      swiftCode: "",
      isPrimary: paymentAccounts.length === 0,
    };
    setPaymentAccounts((prev) => [...prev, newAccount]);
  };

  const updatePaymentAccount = (
    id: string,
    updates: Partial<PaymentAccount>,
  ) => {
    setPaymentAccounts((prev) =>
      prev.map((account) =>
        account.id === id ? { ...account, ...updates } : account,
      ),
    );
  };

  const removePaymentAccount = (id: string) => {
    setPaymentAccounts((prev) => {
      const filtered = prev.filter((account) => account.id !== id);
      // If we removed the primary account, make the first remaining account primary
      if (filtered.length > 0 && !filtered.some((acc) => acc.isPrimary)) {
        filtered[0].isPrimary = true;
      }
      return filtered;
    });
  };

  const setPrimaryAccount = (id: string) => {
    setPaymentAccounts((prev) =>
      prev.map((account) => ({
        ...account,
        isPrimary: account.id === id,
      })),
    );
  };

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!(
          formData.businessName &&
          formData.email &&
          formData.password &&
          formData.confirmPassword &&
          formData.password === formData.confirmPassword
        );
      case 2:
        return (
          paymentAccounts.length >= 1 &&
          paymentAccounts.every(
            (acc) =>
              acc.accountName &&
              acc.providerName &&
              acc.accountNumber &&
              acc.accountHolderName,
          )
        );
      case 3:
        return Object.values(documents).every((doc) => doc !== null);
      default:
        return false;
    }
  };

  const validateDocuments = () => {
    const requiredDocs = [
      { field: "ownerIdDocument", name: "Business Owner/Representative ID" },
      {
        field: "businessAddressProof",
        name: "Proof of Operational Business Address",
      },
      {
        field: "businessRegistrationDoc",
        name: "Business Registration Document",
      },
      { field: "taxClearanceCert", name: "Tax Clearance Certificate" },
    ];

    for (const doc of requiredDocs) {
      if (!documents[doc.field as keyof typeof documents]) {
        setError(`Please upload ${doc.name}`);
        return false;
      }
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (currentStep < 3) {
      if (validateStep(currentStep)) {
        setCurrentStep(currentStep + 1);
        setError("");
      } else {
        setError("Please complete all required fields before proceeding");
      }
      return;
    }

    setIsLoading(true);
    setError("");

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      setIsLoading(false);
      return;
    }

    if (!validateDocuments()) {
      setIsLoading(false);
      return;
    }

    if (paymentAccounts.length === 0) {
      setError("Please add at least one payment account");
      setIsLoading(false);
      return;
    }

    try {
      // Create FormData for file uploads
      const submitData = new FormData();

      // Add form fields
      Object.keys(formData).forEach((key) => {
        if (formData[key as keyof typeof formData]) {
          submitData.append(key, formData[key as keyof typeof formData]);
        }
      });

      // Add payment accounts as JSON
      submitData.append("paymentAccounts", JSON.stringify(paymentAccounts));

      // Add documents
      Object.keys(documents).forEach((key) => {
        const file = documents[key as keyof typeof documents];
        if (file) {
          submitData.append(key, file);
        }
      });

      const response = await fetch("/api/business/register", {
        method: "POST",
        body: submitData,
      });

      const data = await response.json();

      if (response.ok) {
        navigate("/business/login", {
          state: {
            message:
              "Registration successful! Your documents are being reviewed. Please login to continue.",
          },
        });
      } else {
        setError(data.error || "Registration failed");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const bankProviders = [
    "Standard Lesotho Bank",
    "Nedbank Lesotho",
    "First National Bank",
    "PostBank Lesotho",
    "Other",
  ];

  const mobileMoneyProviders = ["M-Pesa", "EcoCash", "Vodacom M-Pesa", "Other"];

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center space-x-2">
            <Link
              to="/"
              className="flex items-center space-x-2 hover:text-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-primary-foreground" />
              </div>
              <h1 className="text-3xl font-bold text-primary">LefaPay</h1>
            </div>
            <h2 className="text-2xl font-semibold mb-2">
              Register Your Business
            </h2>
            <p className="text-muted-foreground">
              Complete setup to start accepting payments
            </p>
          </div>

          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              {[1, 2, 3].map((step) => (
                <div key={step} className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      step <= currentStep
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {step}
                  </div>
                  {step < 3 && (
                    <div
                      className={`w-20 h-1 mx-2 ${
                        step < currentStep ? "bg-primary" : "bg-muted"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Business Info</span>
              <span>Payment Accounts</span>
              <span>Documents</span>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>
                {currentStep === 1 && "Business Information"}
                {currentStep === 2 && "Payment Accounts Setup"}
                {currentStep === 3 && "Document Upload"}
              </CardTitle>
              <CardDescription>
                {currentStep === 1 && "Enter your basic business information"}
                {currentStep === 2 &&
                  "Add accounts where you want to receive payments"}
                {currentStep === 3 &&
                  "Upload required documents for verification"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {error && (
                  <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                    <p className="text-destructive text-sm">{error}</p>
                  </div>
                )}

                {/* Step 1: Business Information */}
                {currentStep === 1 && (
                  <>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="businessName">Business Name *</Label>
                        <Input
                          id="businessName"
                          value={formData.businessName}
                          onChange={(e) =>
                            handleInputChange("businessName", e.target.value)
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="registrationNumber">
                          Registration Number
                        </Label>
                        <Input
                          id="registrationNumber"
                          value={formData.registrationNumber}
                          onChange={(e) =>
                            handleInputChange(
                              "registrationNumber",
                              e.target.value,
                            )
                          }
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) =>
                            handleInputChange("email", e.target.value)
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) =>
                            handleInputChange("phone", e.target.value)
                          }
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="password">Password *</Label>
                        <Input
                          id="password"
                          type="password"
                          value={formData.password}
                          onChange={(e) =>
                            handleInputChange("password", e.target.value)
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">
                          Confirm Password *
                        </Label>
                        <Input
                          id="confirmPassword"
                          type="password"
                          value={formData.confirmPassword}
                          onChange={(e) =>
                            handleInputChange("confirmPassword", e.target.value)
                          }
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="website">Website URL (Optional)</Label>
                      <Input
                        id="website"
                        type="url"
                        value={formData.website}
                        onChange={(e) =>
                          handleInputChange("website", e.target.value)
                        }
                        placeholder="https://your-website.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">
                        Business Description (Optional)
                      </Label>
                      <Input
                        id="description"
                        value={formData.description}
                        onChange={(e) =>
                          handleInputChange("description", e.target.value)
                        }
                        placeholder="Brief description of your business"
                      />
                    </div>
                  </>
                )}

                {/* Step 2: Payment Accounts */}
                {currentStep === 2 && (
                  <>
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-semibold">
                            Payment Receiving Accounts
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            Add at least one account where you want to receive
                            payments
                          </p>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => addPaymentAccount("bank_account")}
                          >
                            <Banknote className="w-4 h-4 mr-2" />
                            Add Bank Account
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => addPaymentAccount("mobile_money")}
                          >
                            <Smartphone className="w-4 h-4 mr-2" />
                            Add Mobile Money
                          </Button>
                        </div>
                      </div>

                      {paymentAccounts.length === 0 && (
                        <div className="text-center py-8 border-2 border-dashed border-muted rounded-lg">
                          <div className="flex justify-center space-x-4 mb-4">
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => addPaymentAccount("bank_account")}
                            >
                              <Banknote className="w-4 h-4 mr-2" />
                              Add Bank Account
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => addPaymentAccount("mobile_money")}
                            >
                              <Smartphone className="w-4 h-4 mr-2" />
                              Add Mobile Money
                            </Button>
                          </div>
                          <p className="text-muted-foreground">
                            Add your receiving accounts to continue
                          </p>
                        </div>
                      )}

                      {paymentAccounts.map((account) => (
                        <Card
                          key={account.id}
                          className={`${account.isPrimary ? "ring-2 ring-primary" : ""}`}
                        >
                          <CardHeader className="pb-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                {account.accountType === "bank_account" ? (
                                  <Banknote className="w-5 h-5 text-primary" />
                                ) : (
                                  <Smartphone className="w-5 h-5 text-primary" />
                                )}
                                <span className="font-medium">
                                  {account.accountType === "bank_account"
                                    ? "Bank Account"
                                    : "Mobile Money"}
                                </span>
                                {account.isPrimary && (
                                  <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded">
                                    Primary
                                  </span>
                                )}
                              </div>
                              <div className="flex space-x-2">
                                {!account.isPrimary && (
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    onClick={() =>
                                      setPrimaryAccount(account.id)
                                    }
                                  >
                                    Make Primary
                                  </Button>
                                )}
                                <Button
                                  type="button"
                                  variant="destructive"
                                  size="sm"
                                  onClick={() =>
                                    removePaymentAccount(account.id)
                                  }
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label>Account Name *</Label>
                                <Input
                                  value={account.accountName}
                                  onChange={(e) =>
                                    updatePaymentAccount(account.id, {
                                      accountName: e.target.value,
                                    })
                                  }
                                  placeholder="e.g., Main Business Account"
                                  required
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Provider *</Label>
                                <Select
                                  value={account.providerName}
                                  onValueChange={(value) =>
                                    updatePaymentAccount(account.id, {
                                      providerName: value,
                                    })
                                  }
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select provider" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {(account.accountType === "bank_account"
                                      ? bankProviders
                                      : mobileMoneyProviders
                                    ).map((provider) => (
                                      <SelectItem
                                        key={provider}
                                        value={provider}
                                      >
                                        {provider}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>

                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label>Account Number *</Label>
                                <Input
                                  value={account.accountNumber}
                                  onChange={(e) =>
                                    updatePaymentAccount(account.id, {
                                      accountNumber: e.target.value,
                                    })
                                  }
                                  placeholder={
                                    account.accountType === "bank_account"
                                      ? "1234567890"
                                      : "266XXXXXXXX"
                                  }
                                  required
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Account Holder Name *</Label>
                                <Input
                                  value={account.accountHolderName}
                                  onChange={(e) =>
                                    updatePaymentAccount(account.id, {
                                      accountHolderName: e.target.value,
                                    })
                                  }
                                  placeholder="Account holder full name"
                                  required
                                />
                              </div>
                            </div>

                            {account.accountType === "bank_account" && (
                              <div className="grid md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <Label>Branch Code</Label>
                                  <Input
                                    value={account.branchCode || ""}
                                    onChange={(e) =>
                                      updatePaymentAccount(account.id, {
                                        branchCode: e.target.value,
                                      })
                                    }
                                    placeholder="Branch code (optional)"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>SWIFT Code</Label>
                                  <Input
                                    value={account.swiftCode || ""}
                                    onChange={(e) =>
                                      updatePaymentAccount(account.id, {
                                        swiftCode: e.target.value,
                                      })
                                    }
                                    placeholder="SWIFT code (optional)"
                                  />
                                </div>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </>
                )}

                {/* Step 3: Documents */}
                {currentStep === 3 && (
                  <div className="space-y-6">
                    <div className="flex items-center space-x-2 mb-4">
                      <FileText className="w-5 h-5 text-primary" />
                      <h3 className="text-lg font-semibold">
                        Required Documents for Verification
                      </h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-6">
                      Documents required to verify this business type. All
                      documents must be uploaded to complete registration.
                    </p>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label
                          htmlFor="ownerIdDocument"
                          className="flex items-center space-x-2"
                        >
                          <span>1. Business Owner/Representative ID *</span>
                        </Label>
                        <div className="flex items-center space-x-2">
                          <Input
                            id="ownerIdDocument"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={(e) =>
                              handleDocumentChange(
                                "ownerIdDocument",
                                e.target.files?.[0] || null,
                              )
                            }
                            required
                          />
                          <Upload className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Upload a copy of the business owner's or authorized
                          representative's national ID
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label
                          htmlFor="businessAddressProof"
                          className="flex items-center space-x-2"
                        >
                          <span>
                            2. Proof of Operational Business Address *
                          </span>
                        </Label>
                        <div className="flex items-center space-x-2">
                          <Input
                            id="businessAddressProof"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={(e) =>
                              handleDocumentChange(
                                "businessAddressProof",
                                e.target.files?.[0] || null,
                              )
                            }
                            required
                          />
                          <Upload className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Utility bill, lease agreement, or official document
                          showing business address
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label
                          htmlFor="businessRegistrationDoc"
                          className="flex items-center space-x-2"
                        >
                          <span>3. Business Registration Document *</span>
                        </Label>
                        <div className="flex items-center space-x-2">
                          <Input
                            id="businessRegistrationDoc"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={(e) =>
                              handleDocumentChange(
                                "businessRegistrationDoc",
                                e.target.files?.[0] || null,
                              )
                            }
                            required
                          />
                          <Upload className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Official business registration certificate or
                          incorporation documents
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label
                          htmlFor="taxClearanceCert"
                          className="flex items-center space-x-2"
                        >
                          <span>
                            4. Tax Clearance Certificate for the Company *
                          </span>
                        </Label>
                        <div className="flex items-center space-x-2">
                          <Input
                            id="taxClearanceCert"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={(e) =>
                              handleDocumentChange(
                                "taxClearanceCert",
                                e.target.files?.[0] || null,
                              )
                            }
                            required
                          />
                          <Upload className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Current tax clearance certificate issued by Lesotho
                          Revenue Authority
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 p-3 bg-muted/50 rounded-md">
                      <p className="text-xs text-muted-foreground">
                        <strong>Note:</strong> All documents should be clear,
                        readable, and in PDF, JPG, JPEG, or PNG format. Maximum
                        file size: 5MB per document. These documents are
                        required for KYC compliance and business verification.
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex justify-between pt-4">
                  {currentStep > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setCurrentStep(currentStep - 1);
                        setError("");
                      }}
                    >
                      Previous
                    </Button>
                  )}

                  <Button
                    type="submit"
                    disabled={isLoading || !validateStep(currentStep)}
                    className={currentStep === 1 ? "ml-auto" : ""}
                  >
                    {isLoading
                      ? "Processing..."
                      : currentStep === 3
                        ? "Register Business"
                        : "Next"}
                  </Button>
                </div>

                {currentStep < 3 && (
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">
                      Already have an account?{" "}
                      <Link
                        to="/business/login"
                        className="text-primary hover:underline"
                      >
                        Sign in here
                      </Link>
                    </p>
                  </div>
                )}
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
