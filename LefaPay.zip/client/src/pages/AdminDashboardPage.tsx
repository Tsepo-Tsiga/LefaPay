import * as React from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Shield,
  LogOut,
  Users,
  DollarSign,
  CreditCard,
  TrendingUp,
  Settings,
  Banknote,
} from "lucide-react";

interface AdminStats {
  totalBusinesses: number;
  pendingKyc: number;
  totalPayments: number;
  totalVolume: number;
  companyRevenue: number;
  revenueTransactions: number;
}

interface Business {
  id: string;
  business_name: string;
  email: string;
  kyc_status: "pending" | "approved" | "rejected";
  is_active: boolean;
  created_at: string;
}

export function AdminDashboardPage() {
  const navigate = useNavigate();
  const [stats, setStats] = React.useState<AdminStats | null>(null);
  const [businesses, setBusinesses] = React.useState<Business[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem("adminToken");
      if (!token) {
        navigate("/admin/login");
        return;
      }

      const [statsRes, businessesRes] = await Promise.all([
        fetch("/api/admin/stats", {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch("/api/admin/businesses", {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (statsRes.ok) {
        setStats(await statsRes.json());
      }
      if (businessesRes.ok) {
        setBusinesses(await businessesRes.json());
      }
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    navigate("/admin/login");
  };

  const handleKycAction = async (
    businessId: string,
    action: "approve" | "reject",
  ) => {
    try {
      const token = localStorage.getItem("adminToken");
      const response = await fetch(`/api/admin/businesses/${businessId}/kyc`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ action }),
      });

      if (response.ok) {
        fetchData(); // Refresh data
      }
    } catch (err) {
      console.error("Error updating KYC status:", err);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-xl font-bold">Lefapay Admin</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link
                to="/admin/revenue"
                className="text-sm hover:text-secondary transition-colors"
              >
                Revenue
              </Link>
              <Link
                to="/admin/bank-account"
                className="text-sm hover:text-secondary transition-colors"
              >
                Bank Account
              </Link>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Dashboard Overview</h2>
          <p className="text-muted-foreground">
            Monitor platform performance and manage businesses
          </p>
        </div>

        {stats && (
          <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Businesses
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats.totalBusinesses}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.pendingKyc} pending KYC
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Payments
                </CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalPayments}</div>
                <p className="text-xs text-muted-foreground">
                  LSL {stats.totalVolume.toFixed(2)} volume
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Company Revenue
                </CardTitle>
                <DollarSign className="h-4 w-4 text-accent" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-accent">
                  LSL {stats.companyRevenue.toFixed(2)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.revenueTransactions} transactions
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Platform Health
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-accent" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-accent">Healthy</div>
                <p className="text-xs text-muted-foreground">
                  All systems operational
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="mb-6 flex items-center justify-between">
          <h3 className="text-xl font-semibold">Business Management</h3>
          <div className="flex space-x-2">
            <Button asChild variant="outline">
              <Link to="/admin/revenue">
                <Banknote className="w-4 h-4 mr-2" />
                View Revenue
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/admin/bank-account">
                <Settings className="w-4 h-4 mr-2" />
                Bank Settings
              </Link>
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Registered Businesses</CardTitle>
            <CardDescription>
              Manage business accounts and KYC status
            </CardDescription>
          </CardHeader>
          <CardContent>
            {businesses.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No businesses registered yet
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Business Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>KYC Status</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {businesses.map((business) => (
                    <TableRow key={business.id}>
                      <TableCell className="font-medium">
                        {business.business_name}
                      </TableCell>
                      <TableCell>{business.email}</TableCell>
                      <TableCell>
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            business.kyc_status === "approved"
                              ? "bg-accent/10 text-accent"
                              : business.kyc_status === "pending"
                                ? "bg-secondary/10 text-secondary"
                                : "bg-destructive/10 text-destructive"
                          }`}
                        >
                          {business.kyc_status}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            business.is_active
                              ? "bg-accent/10 text-accent"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {business.is_active ? "Active" : "Inactive"}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm">
                        {new Date(business.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          {business.kyc_status === "pending" && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  handleKycAction(business.id, "approve")
                                }
                              >
                                Approve
                              </Button>
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() =>
                                  handleKycAction(business.id, "reject")
                                }
                              >
                                Reject
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
