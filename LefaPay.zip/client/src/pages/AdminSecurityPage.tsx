import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Shield, AlertTriangle, CheckCircle, Eye, Settings, Smartphone } from 'lucide-react';

interface SecurityLog {
  id: string;
  event_type: string;
  user_id: string | null;
  ip_address: string | null;
  user_agent: string | null;
  details: string | null;
  status: string;
  created_at: string;
}

interface TwoFactorSetup {
  secret: string;
  qrCode: string;
}

export function AdminSecurityPage() {
  const navigate = useNavigate();
  const [securityLogs, setSecurityLogs] = React.useState<SecurityLog[]>([]);
  const [twoFactorSetup, setTwoFactorSetup] = React.useState<TwoFactorSetup | null>(null);
  const [twoFactorToken, setTwoFactorToken] = React.useState('');
  const [twoFactorEnabled, setTwoFactorEnabled] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(true);
  const [showSetup, setShowSetup] = React.useState(false);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      if (!token) {
        navigate('/admin/login');
        return;
      }

      const response = await fetch('/api/admin/security-logs', {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.ok) {
        setSecurityLogs(await response.json());
      }
    } catch (err) {
      console.error('Error fetching security logs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const setupTwoFactor = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      const response = await fetch('/api/admin/2fa/setup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setTwoFactorSetup(data);
        setShowSetup(true);
      } else {
        alert('Failed to setup 2FA');
      }
    } catch (err) {
      console.error('2FA setup error:', err);
      alert('Failed to setup 2FA');
    }
  };

  const verifyTwoFactor = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      const response = await fetch('/api/admin/2fa/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ token: twoFactorToken })
      });

      if (response.ok) {
        setTwoFactorEnabled(true);
        setShowSetup(false);
        setTwoFactorSetup(null);
        setTwoFactorToken('');
        alert('2FA enabled successfully!');
      } else {
        alert('Invalid token. Please try again.');
      }
    } catch (err) {
      console.error('2FA verification error:', err);
      alert('Failed to verify 2FA token');
    }
  };

  const disableTwoFactor = async () => {
    if (!confirm('Are you sure you want to disable two-factor authentication?')) {
      return;
    }

    try {
      const token = localStorage.getItem('adminToken');
      const response = await fetch('/api/admin/2fa/disable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      });

      if (response.ok) {
        setTwoFactorEnabled(false);
        alert('2FA disabled successfully');
      } else {
        alert('Failed to disable 2FA');
      }
    } catch (err) {
      console.error('2FA disable error:', err);
      alert('Failed to disable 2FA');
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [navigate]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'failure': return 'bg-red-100 text-red-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/admin/dashboard')}
              className="text-primary-foreground hover:text-primary hover:bg-primary-foreground"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 flex items-center space-x-2">
            <Shield className="w-8 h-8 text-primary" />
            <span>Security Center</span>
          </h1>
          <p className="text-muted-foreground">Manage admin security settings and monitor system activity</p>
        </div>

        {/* Two-Factor Authentication */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Smartphone className="w-5 h-5" />
              <span>Two-Factor Authentication</span>
            </CardTitle>
            <CardDescription>
              Add an extra layer of security to your admin account
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!twoFactorEnabled && !showSetup && (
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                  <div>
                    <p className="font-medium">Two-Factor Authentication is disabled</p>
                    <p className="text-sm text-muted-foreground">Protect your account with an authenticator app</p>
                  </div>
                </div>
                <Button onClick={setupTwoFactor}>
                  <Settings className="w-4 h-4 mr-2" />
                  Enable 2FA
                </Button>
              </div>
            )}

            {twoFactorEnabled && (
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="font-medium">Two-Factor Authentication is enabled</p>
                    <p className="text-sm text-muted-foreground">Your account is protected with 2FA</p>
                  </div>
                </div>
                <Button variant="destructive" onClick={disableTwoFactor}>
                  Disable 2FA
                </Button>
              </div>
            )}

            {showSetup && twoFactorSetup && (
              <div className="space-y-4">
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2">Setup Two-Factor Authentication</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
                  </p>
                  <img 
                    src={twoFactorSetup.qrCode} 
                    alt="2FA QR Code" 
                    className="mx-auto mb-4 border rounded"
                  />
                  <p className="text-xs text-muted-foreground mb-4">
                    Manual entry key: <code className="bg-muted px-2 py-1 rounded">{twoFactorSetup.secret}</code>
                  </p>
                </div>
                
                <div className="max-w-sm mx-auto space-y-4">
                  <div>
                    <Label htmlFor="twoFactorToken">Enter verification code from your app</Label>
                    <Input
                      id="twoFactorToken"
                      value={twoFactorToken}
                      onChange={(e) => setTwoFactorToken(e.target.value)}
                      placeholder="000000"
                      maxLength={6}
                    />
                  </div>
                  <div className="flex space-x-2">
                    <Button onClick={verifyTwoFactor} className="flex-1">
                      Verify & Enable
                    </Button>
                    <Button variant="outline" onClick={() => setShowSetup(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Security Logs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Eye className="w-5 h-5" />
              <span>Security Activity Log</span>
            </CardTitle>
            <CardDescription>
              Recent security events and login attempts
            </CardDescription>
          </CardHeader>
          <CardContent>
            {securityLogs.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">No security logs yet</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Event</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Timestamp</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {securityLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-medium">
                        {log.event_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(log.status)}>
                          {log.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {log.ip_address || 'N/A'}
                      </TableCell>
                      <TableCell className="max-w-xs truncate">
                        {log.details || 'No details'}
                      </TableCell>
                      <TableCell className="text-sm">
                        {new Date(log.created_at).toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Security Tips */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Security Best Practices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Password Security</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Use a strong, unique password</li>
                  <li>• Never share your credentials</li>
                  <li>• Change password regularly</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Access Control</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Always log out when finished</li>
                  <li>• Don't access admin panel on public WiFi</li>
                  <li>• Monitor login activity regularly</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Two-Factor Authentication</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Enable 2FA for enhanced security</li>
                  <li>• Use a trusted authenticator app</li>
                  <li>• Keep backup codes secure</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">System Monitoring</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Review security logs regularly</li>
                  <li>• Report suspicious activity</li>
                  <li>• Keep software updated</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
