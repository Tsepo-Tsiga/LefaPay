import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ArrowLeft, Wallet, Plus, TrendingUp, TrendingDown, DollarSign, Eye } from 'lucide-react';

interface Cashbook {
  id: string;
  name: string;
  description: string | null;
  currency: string;
  opening_balance: number;
  current_balance: number;
  is_active: boolean;
  created_at: string;
}

interface CashbookTransaction {
  id: string;
  transaction_type: 'credit' | 'debit';
  amount: number;
  description: string;
  reference: string | null;
  category: string | null;
  payment_method: string | null;
  balance_after: number;
  created_at: string;
}

interface CashbookSummary {
  totalCashbooks: number;
  totalBalance: number;
  activeCashbooks: number;
}

export function CashbooksPage() {
  const navigate = useNavigate();
  const [cashbooks, setCashbooks] = React.useState<Cashbook[]>([]);
  const [summary, setSummary] = React.useState<CashbookSummary>({
    totalCashbooks: 0,
    totalBalance: 0,
    activeCashbooks: 0
  });
  const [selectedCashbook, setSelectedCashbook] = React.useState<Cashbook | null>(null);
  const [transactions, setTransactions] = React.useState<CashbookTransaction[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [showCreateDialog, setShowCreateDialog] = React.useState(false);
  const [showTransactionDialog, setShowTransactionDialog] = React.useState(false);
  const [showTransactionsDialog, setShowTransactionsDialog] = React.useState(false);

  const [createForm, setCreateForm] = React.useState({
    name: '',
    description: '',
    openingBalance: '',
    currency: 'LSL'
  });

  const [transactionForm, setTransactionForm] = React.useState({
    transactionType: 'credit',
    amount: '',
    description: '',
    reference: '',
    category: '',
    paymentMethod: ''
  });

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('businessToken');
      if (!token) {
        navigate('/business/login');
        return;
      }

      const [cashbooksRes, summaryRes] = await Promise.all([
        fetch('/api/business/cashbooks', {
          headers: { Authorization: `Bearer ${token}` }
        }),
        fetch('/api/business/cashbooks/summary', {
          headers: { Authorization: `Bearer ${token}` }
        })
      ]);

      if (cashbooksRes.ok) {
        setCashbooks(await cashbooksRes.json());
      }
      if (summaryRes.ok) {
        setSummary(await summaryRes.json());
      }
    } catch (err) {
      console.error('Error fetching cashbooks:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchTransactions = async (cashbookId: string) => {
    try {
      const token = localStorage.getItem('businessToken');
      const response = await fetch(`/api/business/cashbooks/${cashbookId}/transactions`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.ok) {
        setTransactions(await response.json());
      }
    } catch (err) {
      console.error('Error fetching transactions:', err);
    }
  };

  const handleCreateCashbook = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('businessToken');
      const response = await fetch('/api/business/cashbooks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name: createForm.name,
          description: createForm.description || null,
          openingBalance: parseFloat(createForm.openingBalance) || 0,
          currency: createForm.currency
        })
      });

      if (response.ok) {
        setShowCreateDialog(false);
        setCreateForm({ name: '', description: '', openingBalance: '', currency: 'LSL' });
        fetchData();
        alert('Cashbook created successfully!');
      } else {
        const error = await response.json();
        alert(`Failed to create cashbook: ${error.error}`);
      }
    } catch (err) {
      console.error('Error creating cashbook:', err);
      alert('Failed to create cashbook. Please try again.');
    }
  };

  const handleAddTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCashbook) return;

    try {
      const token = localStorage.getItem('businessToken');
      const response = await fetch(`/api/business/cashbooks/${selectedCashbook.id}/transactions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          transactionType: transactionForm.transactionType,
          amount: parseFloat(transactionForm.amount),
          description: transactionForm.description,
          reference: transactionForm.reference || null,
          category: transactionForm.category || null,
          paymentMethod: transactionForm.paymentMethod || null
        })
      });

      if (response.ok) {
        setShowTransactionDialog(false);
        setTransactionForm({
          transactionType: 'credit',
          amount: '',
          description: '',
          reference: '',
          category: '',
          paymentMethod: ''
        });
        fetchData();
        if (showTransactionsDialog) {
          fetchTransactions(selectedCashbook.id);
        }
        alert('Transaction added successfully!');
      } else {
        const error = await response.json();
        alert(`Failed to add transaction: ${error.error}`);
      }
    } catch (err) {
      console.error('Error adding transaction:', err);
      alert('Failed to add transaction. Please try again.');
    }
  };

  const handleViewTransactions = (cashbook: Cashbook) => {
    setSelectedCashbook(cashbook);
    fetchTransactions(cashbook.id);
    setShowTransactionsDialog(true);
  };

  React.useEffect(() => {
    fetchData();
  }, [navigate]);

  if (isLoading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/business/dashboard')}
              className="text-primary-foreground hover:text-primary hover:bg-primary-foreground"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Cashbooks</h1>
          <p className="text-muted-foreground">Manage your cash accounts and track all financial transactions</p>
        </div>

        {/* Summary Cards */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center space-x-2">
                <Wallet className="w-4 h-4" />
                <span>Total Cashbooks</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summary.totalCashbooks}</div>
              <p className="text-xs text-muted-foreground">{summary.activeCashbooks} active</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center space-x-2">
                <DollarSign className="w-4 h-4" />
                <span>Total Balance</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">LSL {summary.totalBalance.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">Across all cashbooks</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center space-x-2">
                <TrendingUp className="w-4 h-4" />
                <span>Average Balance</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                LSL {summary.totalCashbooks > 0 ? (summary.totalBalance / summary.totalCashbooks).toFixed(2) : '0.00'}
              </div>
              <p className="text-xs text-muted-foreground">Per cashbook</p>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="mb-6">
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create New Cashbook
          </Button>
        </div>

        {/* Cashbooks Table */}
        <Card>
          <CardHeader>
            <CardTitle>Your Cashbooks</CardTitle>
            <CardDescription>All your cash accounts and their current balances</CardDescription>
          </CardHeader>
          <CardContent>
            {cashbooks.length === 0 ? (
              <div className="text-center py-8">
                <Wallet className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No cashbooks created yet</p>
                <Button onClick={() => setShowCreateDialog(true)} className="mt-4">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Cashbook
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Currency</TableHead>
                    <TableHead>Opening Balance</TableHead>
                    <TableHead>Current Balance</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cashbooks.map((cashbook) => (
                    <TableRow key={cashbook.id}>
                      <TableCell className="font-medium">{cashbook.name}</TableCell>
                      <TableCell>{cashbook.description || '-'}</TableCell>
                      <TableCell>{cashbook.currency}</TableCell>
                      <TableCell>LSL {cashbook.opening_balance.toFixed(2)}</TableCell>
                      <TableCell>
                        <span className={`font-medium ${
                          cashbook.current_balance >= 0 ? 'text-accent' : 'text-destructive'
                        }`}>
                          LSL {cashbook.current_balance.toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell>{new Date(cashbook.created_at).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleViewTransactions(cashbook)}
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          <Button 
                            size="sm"
                            onClick={() => {
                              setSelectedCashbook(cashbook);
                              setShowTransactionDialog(true);
                            }}
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            Add Transaction
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Create Cashbook Dialog */}
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Cashbook</DialogTitle>
              <DialogDescription>
                Create a new cash account to track your financial transactions
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateCashbook}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    value={createForm.name}
                    onChange={(e) => setCreateForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Main Cash Account, Petty Cash"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={createForm.description}
                    onChange={(e) => setCreateForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of this cashbook"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="openingBalance">Opening Balance</Label>
                    <Input
                      id="openingBalance"
                      type="number"
                      step="0.01"
                      value={createForm.openingBalance}
                      onChange={(e) => setCreateForm(prev => ({ ...prev, openingBalance: e.target.value }))}
                      placeholder="0.00"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="currency">Currency</Label>
                    <Select value={createForm.currency} onValueChange={(value) => setCreateForm(prev => ({ ...prev, currency: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="LSL">LSL - Lesotho Loti</SelectItem>
                        <SelectItem value="ZAR">ZAR - South African Rand</SelectItem>
                        <SelectItem value="USD">USD - US Dollar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit">Create Cashbook</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Add Transaction Dialog */}
        <Dialog open={showTransactionDialog} onOpenChange={setShowTransactionDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Transaction</DialogTitle>
              <DialogDescription>
                Add a new transaction to {selectedCashbook?.name}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddTransaction}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="transactionType">Type *</Label>
                    <Select value={transactionForm.transactionType} onValueChange={(value) => setTransactionForm(prev => ({ ...prev, transactionType: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="credit">Credit (Money In)</SelectItem>
                        <SelectItem value="debit">Debit (Money Out)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount *</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={transactionForm.amount}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, amount: e.target.value }))}
                      placeholder="0.00"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Input
                    id="description"
                    value={transactionForm.description}
                    onChange={(e) => setTransactionForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of the transaction"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="reference">Reference</Label>
                    <Input
                      id="reference"
                      value={transactionForm.reference}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, reference: e.target.value }))}
                      placeholder="Reference number or code"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      value={transactionForm.category}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, category: e.target.value }))}
                      placeholder="e.g., Sales, Expenses, Transfer"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="paymentMethod">Payment Method</Label>
                  <Select value={transactionForm.paymentMethod} onValueChange={(value) => setTransactionForm(prev => ({ ...prev, paymentMethod: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">None</SelectItem>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                      <SelectItem value="mobile_money">Mobile Money</SelectItem>
                      <SelectItem value="card">Card Payment</SelectItem>
                      <SelectItem value="cheque">Cheque</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowTransactionDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit">Add Transaction</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* View Transactions Dialog */}
        <Dialog open={showTransactionsDialog} onOpenChange={setShowTransactionsDialog}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedCashbook?.name} - Transactions</DialogTitle>
              <DialogDescription>
                Current Balance: LSL {selectedCashbook?.current_balance.toFixed(2)}
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              {transactions.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No transactions yet</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Balance After</TableHead>
                      <TableHead>Reference</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>{new Date(transaction.created_at).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            {transaction.transaction_type === 'credit' ? (
                              <TrendingUp className="w-4 h-4 text-accent" />
                            ) : (
                              <TrendingDown className="w-4 h-4 text-destructive" />
                            )}
                            <span className="capitalize">{transaction.transaction_type}</span>
                          </div>
                        </TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell>
                          <span className={transaction.transaction_type === 'credit' ? 'text-accent' : 'text-destructive'}>
                            {transaction.transaction_type === 'credit' ? '+' : '-'}LSL {transaction.amount.toFixed(2)}
                          </span>
                        </TableCell>
                        <TableCell>LSL {transaction.balance_after.toFixed(2)}</TableCell>
                        <TableCell>{transaction.reference || '-'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
            <DialogFooter>
              <Button 
                onClick={() => {
                  setShowTransactionDialog(true);
                }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Transaction
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
