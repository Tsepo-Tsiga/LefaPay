import * as React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft, Plus, Banknote, Smartphone, Edit, Star } from 'lucide-react';

interface PaymentAccount {
  id: string;
  account_type: 'bank_account' | 'mobile_money';
  account_name: string;
  provider_name: string;
  account_number: string;
  account_holder_name: string;
  branch_code: string | null;
  swift_code: string | null;
  is_primary: boolean;
  is_active: boolean;
  verification_status: 'pending' | 'verified' | 'rejected';
  created_at: string;
}

export function PaymentAccountsPage() {
  const navigate = useNavigate();
  const [accounts, setAccounts] = React.useState<PaymentAccount[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [showAddDialog, setShowAddDialog] = React.useState(false);
  const [newAccount, setNewAccount] = React.useState({
    accountType: 'bank_account' as 'bank_account' | 'mobile_money',
    accountName: '',
    providerName: '',
    accountNumber: '',
    accountHolderName: '',
    branchCode: '',
    swiftCode: '',
    isPrimary: false
  });

  const fetchAccounts = async () => {
    try {
      const token = localStorage.getItem('businessToken');
      if (!token) {
        navigate('/business/login');
        return;
      }

      const response = await fetch('/api/business/payment-accounts', {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.ok) {
        setAccounts(await response.json());
      }
    } catch (err) {
      console.error('Error fetching accounts:', err);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchAccounts();
  }, [navigate]);

  const handleAddAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const token = localStorage.getItem('businessToken');
      const response = await fetch('/api/business/payment-accounts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          accountType: newAccount.accountType,
          accountName: newAccount.accountName,
          providerName: newAccount.providerName,
          accountNumber: newAccount.accountNumber,
          accountHolderName: newAccount.accountHolderName,
          branchCode: newAccount.branchCode || null,
          swiftCode: newAccount.swiftCode || null,
          isPrimary: newAccount.isPrimary || accounts.length === 0
        })
      });

      if (response.ok) {
        setShowAddDialog(false);
        setNewAccount({
          accountType: 'bank_account',
          accountName: '',
          providerName: '',
          accountNumber: '',
          accountHolderName: '',
          branchCode: '',
          swiftCode: '',
          isPrimary: false
        });
        fetchAccounts();
        alert('Payment account added successfully!');
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to add account');
      }
    } catch (err) {
      console.error('Error adding account:', err);
      alert('Failed to add account');
    }
  };

  const bankProviders = [
    'Standard Lesotho Bank',
    'Nedbank Lesotho',
    'First National Bank',
    'PostBank Lesotho',
    'Other'
  ];

  const mobileMoneyProviders = [
    'M-Pesa',
    'EcoCash',
    'Vodacom M-Pesa',
    'Other'
  ];

  if (isLoading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link to="/business/dashboard" className="flex items-center space-x-2 hover:text-secondary transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Dashboard</span>
              </Link>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <Banknote className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-xl font-bold">Payment Accounts</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Payment Receiving Accounts</h2>
          <p className="text-muted-foreground">
            Manage the accounts where you receive payments from customers
          </p>
        </div>

        <div className="mb-6">
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add Payment Account
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Your Payment Accounts</CardTitle>
            <CardDescription>
              Accounts configured to receive payments from customers
            </CardDescription>
          </CardHeader>
          <CardContent>
            {accounts.length === 0 ? (
              <div className="text-center py-8">
                <div className="flex justify-center space-x-4 mb-4">
                  <Banknote className="w-12 h-12 text-muted-foreground" />
                  <Smartphone className="w-12 h-12 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground">No payment accounts configured yet</p>
                <Button onClick={() => setShowAddDialog(true)} className="mt-4">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Account
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Account</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Provider</TableHead>
                    <TableHead>Account Number</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {accounts.map((account) => (
                    <TableRow key={account.id}>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          {account.account_type === 'bank_account' ? (
                            <Banknote className="w-4 h-4 text-accent" />
                          ) : (
                            <Smartphone className="w-4 h-4 text-accent" />
                          )}
                          <div>
                            <div className="font-medium flex items-center space-x-1">
                              <span>{account.account_name}</span>
                              {account.is_primary && (
                                <Star className="w-4 h-4 text-primary" />
                              )}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {account.account_holder_name}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="capitalize">
                          {account.account_type.replace('_', ' ')}
                        </span>
                      </TableCell>
                      <TableCell>{account.provider_name}</TableCell>
                      <TableCell className="font-mono">
                        {account.account_number}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            account.verification_status === 'verified'
                              ? 'bg-accent/10 text-accent'
                              : account.verification_status === 'pending'
                              ? 'bg-secondary/10 text-secondary'
                              : 'bg-destructive/10 text-destructive'
                          }`}>
                            {account.verification_status}
                          </span>
                          {account.is_primary && (
                            <div className="text-xs text-primary font-medium">
                              Primary
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          {!account.is_primary && (
                            <Button variant="outline" size="sm">
                              Make Primary
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Important Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-2">Account Verification</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• All accounts require verification before receiving payments</li>
                  <li>• Verification typically takes 1-2 business days</li>
                  <li>• You'll be notified via email once verified</li>
                  <li>• Ensure account details are accurate to avoid delays</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Payment Processing</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Your primary account receives payments by default</li>
                  <li>• Payments are processed within 24-48 hours</li>
                  <li>• Mobile money transfers are typically faster</li>
                  <li>• Bank transfers may take longer during holidays</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Add Account Dialog */}
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Add Payment Account</DialogTitle>
              <DialogDescription>
                Add a new account where you want to receive payments
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddAccount}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>Account Type</Label>
                  <Select
                    value={newAccount.accountType}
                    onValueChange={(value) => setNewAccount(prev => ({ 
                      ...prev, 
                      accountType: value as 'bank_account' | 'mobile_money',
                      providerName: '' // Reset provider when type changes
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bank_account">Bank Account</SelectItem>
                      <SelectItem value="mobile_money">Mobile Money</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Account Name *</Label>
                    <Input
                      value={newAccount.accountName}
                      onChange={(e) => setNewAccount(prev => ({ ...prev, accountName: e.target.value }))}
                      placeholder="e.g., Main Business Account"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Provider *</Label>
                    <Select
                      value={newAccount.providerName}
                      onValueChange={(value) => setNewAccount(prev => ({ ...prev, providerName: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select provider" />
                      </SelectTrigger>
                      <SelectContent>
                        {(newAccount.accountType === 'bank_account' ? bankProviders : mobileMoneyProviders).map(provider => (
                          <SelectItem key={provider} value={provider}>{provider}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Account Number *</Label>
                    <Input
                      value={newAccount.accountNumber}
                      onChange={(e) => setNewAccount(prev => ({ ...prev, accountNumber: e.target.value }))}
                      placeholder={newAccount.accountType === 'bank_account' ? '1234567890' : '266XXXXXXXX'}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Account Holder Name *</Label>
                    <Input
                      value={newAccount.accountHolderName}
                      onChange={(e) => setNewAccount(prev => ({ ...prev, accountHolderName: e.target.value }))}
                      placeholder="Account holder full name"
                      required
                    />
                  </div>
                </div>

                {newAccount.accountType === 'bank_account' && (
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Branch Code</Label>
                      <Input
                        value={newAccount.branchCode}
                        onChange={(e) => setNewAccount(prev => ({ ...prev, branchCode: e.target.value }))}
                        placeholder="Branch code (optional)"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>SWIFT Code</Label>
                      <Input
                        value={newAccount.swiftCode}
                        onChange={(e) => setNewAccount(prev => ({ ...prev, swiftCode: e.target.value }))}
                        placeholder="SWIFT code (optional)"
                      />
                    </div>
                  </div>
                )}

                {accounts.length > 0 && (
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="primary"
                      checked={newAccount.isPrimary}
                      onCheckedChange={(checked) => setNewAccount(prev => ({ ...prev, isPrimary: checked }))}
                    />
                    <Label htmlFor="primary">Make this the primary account</Label>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit">Add Account</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
