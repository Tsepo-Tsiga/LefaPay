import * as React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  CreditCard,
  DollarSign,
  Link2,
  LogOut,
  Plus,
  TrendingUp,
  Users,
  FileText,
  Banknote,
  AlertTriangle,
} from "lucide-react";
import { CreatePaymentLinkDialog } from "@/components/CreatePaymentLinkDialog";

interface Business {
  id: string;
  business_name: string;
  email: string;
  kyc_status: "pending" | "approved" | "rejected";
  is_active: boolean;
  payment_accounts_completed: boolean;
  profile_completion_percentage: number;
}

interface Payment {
  id: string;
  amount: number;
  currency: string;
  status: "pending" | "completed" | "failed" | "cancelled";
  customer_email: string | null;
  customer_name: string | null;
  description: string | null;
  created_at: string;
}

interface PaymentLink {
  id: string;
  title: string;
  amount: number | null;
  is_fixed_amount: boolean;
  description: string | null;
  is_active: boolean;
  created_at: string;
}

export function BusinessDashboardPage() {
  const navigate = useNavigate();
  const [business, setBusiness] = React.useState<Business | null>(null);
  const [payments, setPayments] = React.useState<Payment[]>([]);
  const [paymentLinks, setPaymentLinks] = React.useState<PaymentLink[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [showCreateLink, setShowCreateLink] = React.useState(false);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem("businessToken");
      if (!token) {
        navigate("/business/login");
        return;
      }

      const [businessRes, paymentsRes, linksRes] = await Promise.all([
        fetch("/api/business/profile", {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch("/api/business/payments", {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch("/api/business/payment-links", {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (businessRes.ok) {
        setBusiness(await businessRes.json());
      }
      if (paymentsRes.ok) {
        setPayments(await paymentsRes.json());
      }
      if (linksRes.ok) {
        setPaymentLinks(await linksRes.json());
      }
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("businessToken");
    navigate("/");
  };

  const getPaymentLinkUrl = (linkId: string) => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/pay/${linkId}`;
  };

  const handleCopyLink = (linkId: string) => {
    const url = getPaymentLinkUrl(linkId);
    navigator.clipboard.writeText(url);
    alert("Payment link copied to clipboard!");
  };

  const totalAmount = payments
    .filter((p) => p.status === "completed")
    .reduce((sum, p) => sum + p.amount, 0);

  const completedPayments = payments.filter(
    (p) => p.status === "completed",
  ).length;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        Loading...
      </div>
    );
  }

  if (!business) {
    navigate("/business/login");
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-xl font-bold">LefaPay Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm">{business.business_name}</span>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Account Setup Alerts */}
        {!business.payment_accounts_completed && (
          <div className="mb-6 p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              <h3 className="font-semibold text-destructive">
                Payment Accounts Required
              </h3>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              You need to configure at least one payment account to receive
              funds from customers.
            </p>
            <Button
              onClick={() => navigate("/business/payment-accounts")}
              size="sm"
            >
              <Banknote className="w-4 h-4 mr-2" />
              Setup Payment Accounts
            </Button>
          </div>
        )}

        {business.kyc_status === "pending" && (
          <div className="mb-6 p-4 bg-secondary/10 border border-secondary/20 rounded-lg">
            <h3 className="font-semibold text-secondary mb-2">
              Account Under Review
            </h3>
            <p className="text-sm text-muted-foreground">
              Your account is currently being reviewed. You can create payment
              links, but payments will be processed once approved.
            </p>
          </div>
        )}

        {business.kyc_status === "rejected" && (
          <div className="mb-6 p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
            <h3 className="font-semibold text-destructive mb-2">
              Account Rejected
            </h3>
            <p className="text-sm text-muted-foreground">
              Your account application was rejected. Please contact support for
              more information.
            </p>
          </div>
        )}

        <div className="grid lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Revenue
              </CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                LSL {totalAmount.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">
                Total payments received
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Successful Payments
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">
                {completedPayments}
              </div>
              <p className="text-xs text-muted-foreground">
                Completed transactions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Payment Links
              </CardTitle>
              <Link2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{paymentLinks.length}</div>
              <p className="text-xs text-muted-foreground">
                Active payment links
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Status</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold capitalize">
                {business.kyc_status === "approved" ? (
                  <span className="text-accent">Active</span>
                ) : (
                  <span className="text-secondary">{business.kyc_status}</span>
                )}
              </div>
              <p className="text-xs text-muted-foreground">Account status</p>
            </CardContent>
          </Card>
        </div>

        <div className="mb-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Quick Actions</h2>
          </div>
          <div className="grid md:grid-cols-4 gap-4 mt-4">
            <Button onClick={() => setShowCreateLink(true)} className="h-16">
              <Plus className="w-5 h-5 mr-2" />
              Create Payment Link
            </Button>
            <Button
              variant="outline"
              className="h-16"
              onClick={() => navigate("/business/reports")}
            >
              <FileText className="w-5 h-5 mr-2" />
              View Sales Reports
            </Button>
            <Button
              variant="outline"
              className="h-16"
              onClick={() => navigate("/business/fees")}
            >
              <DollarSign className="w-5 h-5 mr-2" />
              View Fees & Charges
            </Button>
            <Button
              variant="outline"
              className="h-16"
              onClick={() => navigate("/business/payment-accounts")}
            >
              <Banknote className="w-5 h-5 mr-2" />
              Payment Accounts
            </Button>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Payment Links</CardTitle>
                    <CardDescription>
                      Create and manage your payment links
                    </CardDescription>
                  </div>
                  <Button onClick={() => setShowCreateLink(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Link
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {paymentLinks.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">
                    No payment links created yet
                  </p>
                ) : (
                  <div className="space-y-4">
                    {paymentLinks.slice(0, 3).map((link) => (
                      <div
                        key={link.id}
                        className="flex items-center justify-between p-3 border rounded-lg"
                      >
                        <div>
                          <h4 className="font-medium">{link.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {link.is_fixed_amount
                              ? `LSL ${link.amount?.toFixed(2)}`
                              : "Variable amount"}
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCopyLink(link.id)}
                        >
                          Copy Link
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>
                  Your latest payment transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                {payments.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">
                    No transactions yet
                  </p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {payments.slice(0, 5).map((payment) => (
                        <TableRow key={payment.id}>
                          <TableCell>LSL {payment.amount.toFixed(2)}</TableCell>
                          <TableCell>
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                payment.status === "completed"
                                  ? "bg-accent/10 text-accent"
                                  : payment.status === "pending"
                                    ? "bg-secondary/10 text-secondary"
                                    : "bg-destructive/10 text-destructive"
                              }`}
                            >
                              {payment.status}
                            </span>
                          </TableCell>
                          <TableCell className="text-sm">
                            {new Date(payment.created_at).toLocaleDateString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <CreatePaymentLinkDialog
        open={showCreateLink}
        onOpenChange={setShowCreateLink}
        onSuccess={fetchData}
      />
    </div>
  );
}
