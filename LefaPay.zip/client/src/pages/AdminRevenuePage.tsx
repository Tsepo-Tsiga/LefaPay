import * as React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Shield, ArrowLeft, Download, Banknote } from 'lucide-react';

interface RevenueRecord {
  id: string;
  revenue_type: 'transaction_fee' | 'subscription_fee';
  amount: number;
  description: string | null;
  transferred_to_bank: boolean;
  transfer_date: string | null;
  created_at: string;
  business_name: string | null;
}

export function AdminRevenuePage() {
  const navigate = useNavigate();
  const [revenue, setRevenue] = React.useState<RevenueRecord[]>([]);
  const [selectedRevenue, setSelectedRevenue] = React.useState<string[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isTransferring, setIsTransferring] = React.useState(false);

  const fetchRevenue = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      if (!token) {
        navigate('/admin/login');
        return;
      }

      const response = await fetch('/api/admin/revenue', {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.ok) {
        setRevenue(await response.json());
      }
    } catch (err) {
      console.error('Error fetching revenue:', err);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchRevenue();
  }, [navigate]);

  const handleSelectRevenue = (revenueId: string, checked: boolean) => {
    if (checked) {
      setSelectedRevenue(prev => [...prev, revenueId]);
    } else {
      setSelectedRevenue(prev => prev.filter(id => id !== revenueId));
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const availableIds = revenue
        .filter(r => !r.transferred_to_bank)
        .map(r => r.id);
      setSelectedRevenue(availableIds);
    } else {
      setSelectedRevenue([]);
    }
  };

  const handleTransfer = async () => {
    if (selectedRevenue.length === 0) return;

    setIsTransferring(true);
    try {
      const token = localStorage.getItem('adminToken');
      const response = await fetch('/api/admin/revenue/transfer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ revenueIds: selectedRevenue })
      });

      if (response.ok) {
        setSelectedRevenue([]);
        fetchRevenue(); // Refresh data
        alert('Revenue transferred successfully!');
      } else {
        const data = await response.json();
        alert(data.message || 'Transfer failed');
      }
    } catch (err) {
      console.error('Error transferring revenue:', err);
      alert('Transfer failed');
    } finally {
      setIsTransferring(false);
    }
  };

  const totalRevenue = revenue.reduce((sum, r) => sum + r.amount, 0);
  const transferredRevenue = revenue
    .filter(r => r.transferred_to_bank)
    .reduce((sum, r) => sum + r.amount, 0);
  const pendingRevenue = totalRevenue - transferredRevenue;

  if (isLoading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link to="/admin/dashboard" className="flex items-center space-x-2 hover:text-secondary transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Dashboard</span>
              </Link>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-xl font-bold">Revenue Management</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <Banknote className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">LSL {totalRevenue.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                All time earnings
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Transferred</CardTitle>
              <Download className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">LSL {transferredRevenue.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                Already transferred
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Transfer</CardTitle>
              <Banknote className="h-4 w-4 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary">LSL {pendingRevenue.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                Available for transfer
              </p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Revenue Records</CardTitle>
                <CardDescription>Manage company revenue and bank transfers</CardDescription>
              </div>
              {selectedRevenue.length > 0 && (
                <Button onClick={handleTransfer} disabled={isTransferring}>
                  {isTransferring ? 'Transferring...' : `Transfer ${selectedRevenue.length} Selected`}
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {revenue.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No revenue records yet
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={selectedRevenue.length > 0 && selectedRevenue.length === revenue.filter(r => !r.transferred_to_bank).length}
                        onCheckedChange={handleSelectAll}
                      />
                    </TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Business</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {revenue.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        {!record.transferred_to_bank && (
                          <Checkbox
                            checked={selectedRevenue.includes(record.id)}
                            onCheckedChange={(checked) => handleSelectRevenue(record.id, checked as boolean)}
                          />
                        )}
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          record.revenue_type === 'transaction_fee'
                            ? 'bg-accent/10 text-accent'
                            : 'bg-secondary/10 text-secondary'
                        }`}>
                          {record.revenue_type === 'transaction_fee' ? 'Transaction Fee' : 'Subscription'}
                        </span>
                      </TableCell>
                      <TableCell>{record.business_name || 'N/A'}</TableCell>
                      <TableCell className="font-medium">LSL {record.amount.toFixed(2)}</TableCell>
                      <TableCell className="text-sm">{record.description}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          record.transferred_to_bank
                            ? 'bg-accent/10 text-accent'
                            : 'bg-secondary/10 text-secondary'
                        }`}>
                          {record.transferred_to_bank ? 'Transferred' : 'Pending'}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm">
                        {new Date(record.created_at).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
