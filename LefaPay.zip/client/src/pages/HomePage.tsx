import * as React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { CreditCard, Shield, Smartphone, TrendingUp } from "lucide-react";

export function HomePage() {
  return (
    <div className="min-h-screen">
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-2xl font-bold">LefaPay</h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              <Link
                to="/business/login"
                className="hover:text-secondary transition-colors"
              >
                Business Login
              </Link>
              <Link
                to="/admin/login"
                className="hover:text-secondary transition-colors"
              >
                Admin
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main>
        <section className="bg-primary text-primary-foreground py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-5xl font-bold mb-6">
              Accept Payments in Lesotho
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Secure payment processing for businesses. Accept mobile money,
              cards, and bank transfers with ease.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" variant="secondary">
                <Link to="/business/signup">Start Accepting Payments</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
              >
                <Link to="/business/login">Business Login</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <h3 className="text-3xl font-bold text-center mb-12">
              Payment Methods
            </h3>
            <div className="grid md:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Smartphone className="w-6 h-6 text-accent" />
                    <span>Mobile Money</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Accept M-Pesa, EcoCash and other mobile money payments from
                    your customers
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <CreditCard className="w-6 h-6 text-accent" />
                    <span>Card Payments</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Visa, Mastercard and other major credit and debit cards
                    supported
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-6 h-6 text-accent" />
                    <span>Bank Transfers</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    EFT from Standard Lesotho Bank, Nedbank, FNB and other local
                    banks
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="bg-muted py-20">
          <div className="container mx-auto px-4">
            <h3 className="text-3xl font-bold text-center mb-12">
              Why Choose LefaPay?
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <Shield className="w-12 h-12 text-accent mx-auto mb-4" />
                <h4 className="text-xl font-semibold mb-2">Secure</h4>
                <p className="text-muted-foreground">
                  Bank-level security with encryption and fraud protection
                </p>
              </div>
              <div className="text-center">
                <CreditCard className="w-12 h-12 text-accent mx-auto mb-4" />
                <h4 className="text-xl font-semibold mb-2">Easy Integration</h4>
                <p className="text-muted-foreground">
                  Simple payment links or embed directly on your website
                </p>
              </div>
              <div className="text-center">
                <Smartphone className="w-12 h-12 text-accent mx-auto mb-4" />
                <h4 className="text-xl font-semibold mb-2">Mobile Optimized</h4>
                <p className="text-muted-foreground">
                  Perfect experience on all devices, especially mobile
                </p>
              </div>
              <div className="text-center">
                <TrendingUp className="w-12 h-12 text-accent mx-auto mb-4" />
                <h4 className="text-xl font-semibold mb-2">Analytics</h4>
                <p className="text-muted-foreground">
                  Track your payments and business performance
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-primary text-primary-foreground py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2024 LefaPay. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
