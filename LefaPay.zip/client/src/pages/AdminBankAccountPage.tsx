import * as React from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Shield, ArrowLeft, Banknote } from "lucide-react";

interface BankAccount {
  bankName: string | null;
  accountNumber: string | null;
  accountHolder: string | null;
  bankBranch: string | null;
  swiftCode: string | null;
}

export function AdminBankAccountPage() {
  const navigate = useNavigate();
  const [bankAccount, setBankAccount] = React.useState<BankAccount>({
    bankName: null,
    accountNumber: null,
    accountHolder: null,
    bankBranch: null,
    swiftCode: null,
  });
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSaving, setIsSaving] = React.useState(false);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");

  const fetchBankAccount = async () => {
    try {
      const token = localStorage.getItem("adminToken");
      if (!token) {
        navigate("/admin/login");
        return;
      }

      const response = await fetch("/api/admin/bank-account", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        setBankAccount(await response.json());
      }
    } catch (err) {
      console.error("Error fetching bank account:", err);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchBankAccount();
  }, [navigate]);

  const handleInputChange = (field: keyof BankAccount, value: string) => {
    setBankAccount((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setError("");
    setSuccess("");

    try {
      const token = localStorage.getItem("adminToken");
      const response = await fetch("/api/admin/bank-account", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(bankAccount),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess("Bank account details updated successfully!");
      } else {
        setError(data.error || "Failed to update bank account");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link
                to="/admin/dashboard"
                className="flex items-center space-x-2 hover:text-secondary transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Dashboard</span>
              </Link>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-xl font-bold">Bank Account Settings</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="mb-8">
            <div className="flex items-center space-x-2 mb-4">
              <Banknote className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-bold">Company Bank Account</h2>
            </div>
            <p className="text-muted-foreground">
              Configure the bank account where Lefapay company revenue will be
              transferred.
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Bank Account Details</CardTitle>
              <CardDescription>
                Enter your company's bank account information for revenue
                transfers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {error && (
                  <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                    <p className="text-destructive text-sm">{error}</p>
                  </div>
                )}

                {success && (
                  <div className="p-3 bg-accent/10 border border-accent/20 rounded-md">
                    <p className="text-accent text-sm">{success}</p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="bankName">Bank Name *</Label>
                  <Select
                    value={bankAccount.bankName || ""}
                    onValueChange={(value) =>
                      handleInputChange("bankName", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select bank" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard-lesotho">
                        Standard Lesotho Bank
                      </SelectItem>
                      <SelectItem value="nedbank">Nedbank Lesotho</SelectItem>
                      <SelectItem value="fnb">First National Bank</SelectItem>
                      <SelectItem value="postbank">PostBank Lesotho</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="accountNumber">Account Number *</Label>
                    <Input
                      id="accountNumber"
                      value={bankAccount.accountNumber || ""}
                      onChange={(e) =>
                        handleInputChange("accountNumber", e.target.value)
                      }
                      placeholder="1234567890"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountHolder">Account Holder Name *</Label>
                    <Input
                      id="accountHolder"
                      value={bankAccount.accountHolder || ""}
                      onChange={(e) =>
                        handleInputChange("accountHolder", e.target.value)
                      }
                      placeholder="PayLesotho (Pty) Ltd"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bankBranch">Bank Branch (Optional)</Label>
                    <Input
                      id="bankBranch"
                      value={bankAccount.bankBranch || ""}
                      onChange={(e) =>
                        handleInputChange("bankBranch", e.target.value)
                      }
                      placeholder="Maseru Main Branch"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="swiftCode">
                      SWIFT/Routing Code (Optional)
                    </Label>
                    <Input
                      id="swiftCode"
                      value={bankAccount.swiftCode || ""}
                      onChange={(e) =>
                        handleInputChange("swiftCode", e.target.value)
                      }
                      placeholder="SBICLS22"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <Button type="submit" disabled={isSaving} className="w-full">
                    {isSaving ? "Saving..." : "Save Bank Account Details"}
                  </Button>
                </div>

                <div className="p-4 bg-muted/50 rounded-md">
                  <h4 className="font-medium mb-2">Important Notes:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>
                      • Revenue transfers require these details to be configured
                    </li>
                    <li>• All transfers are logged for audit purposes</li>
                    <li>
                      • Contact your bank for specific account requirements
                    </li>
                    <li>
                      • Changes to these details affect future transfers only
                    </li>
                  </ul>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
