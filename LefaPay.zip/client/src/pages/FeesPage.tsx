import * as React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CreditCard, ArrowLeft, DollarSign, Calendar, Receipt } from 'lucide-react';

interface TransactionFee {
  id: string;
  transaction_amount: number;
  fee_amount: number;
  net_amount: number;
  status: string;
  created_at: string;
  reference: string | null;
  customer_name: string | null;
}

interface SubscriptionFee {
  id: string;
  amount: number;
  currency: string;
  billing_period: string;
  due_date: string;
  paid_date: string | null;
  status: 'pending' | 'paid' | 'overdue';
  payment_method: string | null;
  created_at: string;
}

export function FeesPage() {
  const navigate = useNavigate();
  const [transactionFees, setTransactionFees] = React.useState<TransactionFee[]>([]);
  const [subscriptionFees, setSubscriptionFees] = React.useState<SubscriptionFee[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  const fetchFees = async () => {
    try {
      const token = localStorage.getItem('businessToken');
      if (!token) {
        navigate('/business/login');
        return;
      }

      const [transactionRes, subscriptionRes] = await Promise.all([
        fetch('/api/business/fees/transactions', {
          headers: { Authorization: `Bearer ${token}` }
        }),
        fetch('/api/business/fees/subscriptions', {
          headers: { Authorization: `Bearer ${token}` }
        })
      ]);

      if (transactionRes.ok) {
        setTransactionFees(await transactionRes.json());
      }
      if (subscriptionRes.ok) {
        setSubscriptionFees(await subscriptionRes.json());
      }
    } catch (err) {
      console.error('Error fetching fees:', err);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchFees();
  }, [navigate]);

  const handlePaySubscription = async (subscriptionId: string) => {
    try {
      const token = localStorage.getItem('businessToken');
      const response = await fetch(`/api/business/fees/subscriptions/${subscriptionId}/pay`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ paymentMethod: 'card' })
      });

      if (response.ok) {
        fetchFees(); // Refresh data
        alert('Subscription fee paid successfully!');
      } else {
        const data = await response.json();
        alert(data.error || 'Payment failed');
      }
    } catch (err) {
      console.error('Error paying subscription:', err);
      alert('Payment failed');
    }
  };

  const totalTransactionFees = transactionFees.reduce((sum, fee) => sum + fee.fee_amount, 0);
  const totalNetAmount = transactionFees.reduce((sum, fee) => sum + fee.net_amount, 0);
  const pendingSubscriptions = subscriptionFees.filter(s => s.status === 'pending').length;

  if (isLoading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link to="/business/dashboard" className="flex items-center space-x-2 hover:text-secondary transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Dashboard</span>
              </Link>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-xl font-bold">Fees & Charges</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Fees Overview</h2>
          <p className="text-muted-foreground">Track transaction fees and subscription charges</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Transaction Fees Paid</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">LSL {totalTransactionFees.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                5.7% of transaction volume
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Net Amount Received</CardTitle>
              <DollarSign className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">LSL {totalNetAmount.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                After transaction fees
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Subscriptions</CardTitle>
              <Calendar className="h-4 w-4 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary">{pendingSubscriptions}</div>
              <p className="text-xs text-muted-foreground">
                Monthly fees due
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <Receipt className="w-5 h-5 text-primary" />
                <div>
                  <CardTitle>Subscription Fees</CardTitle>
                  <CardDescription>Monthly platform subscription charges</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {subscriptionFees.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  No subscription fees yet
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Period</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {subscriptionFees.map((fee) => (
                      <TableRow key={fee.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{fee.billing_period}</div>
                            <div className="text-sm text-muted-foreground">
                              Due: {new Date(fee.due_date).toLocaleDateString()}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">
                          {fee.currency} {fee.amount.toFixed(2)}
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            fee.status === 'paid' 
                              ? 'bg-accent/10 text-accent'
                              : fee.status === 'pending'
                              ? 'bg-secondary/10 text-secondary'
                              : 'bg-destructive/10 text-destructive'
                          }`}>
                            {fee.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          {fee.status === 'pending' && (
                            <Button 
                              size="sm" 
                              onClick={() => handlePaySubscription(fee.id)}
                            >
                              Pay Now
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <DollarSign className="w-5 h-5 text-primary" />
                <div>
                  <CardTitle>Transaction Fees</CardTitle>
                  <CardDescription>5.7% fee charged on each transaction</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {transactionFees.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  No transaction fees yet
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Transaction</TableHead>
                      <TableHead>Fee</TableHead>
                      <TableHead>Net Amount</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactionFees.slice(0, 10).map((fee) => (
                      <TableRow key={fee.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">LSL {fee.transaction_amount.toFixed(2)}</div>
                            <div className="text-sm text-muted-foreground">
                              {fee.reference || fee.customer_name || 'N/A'}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-destructive">
                          -LSL {fee.fee_amount.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-accent font-medium">
                          LSL {fee.net_amount.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(fee.created_at).toLocaleDateString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Fee Structure</CardTitle>
            <CardDescription>Understanding PayLesotho charges</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-2">Transaction Fees</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• 5.7% charged on each completed payment</li>
                  <li>• Deducted automatically from transaction amount</li>
                  <li>• No setup or hidden fees</li>
                  <li>• Transparent pricing structure</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Subscription Fees</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• LSL 300 monthly platform subscription</li>
                  <li>• Includes access to dashboard and reports</li>
                  <li>• Payment link creation and management</li>
                  <li>• Customer support included</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
